/**
 * Seed demo data for RushEnd
 * Creates 3 businesses (hospital, restaurant, bank) with counters, queues, and sample data
 */

require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Missing SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { autoRefreshToken: false, persistSession: false }
});

async function seed() {
  console.log('Seeding RushEnd demo data...\n');

  // 1. Create demo staff users
  console.log('Creating demo staff users...');

  const staffUsers = [
    { email: 'hospital@rushend.demo', password: 'demo123456', full_name: 'City Hospital Admin', role: 'staff' },
    { email: 'restaurant@rushend.demo', password: 'demo123456', full_name: 'Spice Garden Manager', role: 'staff' },
    { email: 'bank@rushend.demo', password: 'demo123456', full_name: 'State Bank Admin', role: 'staff' },
  ];

  const staffProfiles = [];
  for (const user of staffUsers) {
    const { data, error } = await supabase.auth.signUp({
      email: user.email,
      password: user.password,
      options: { data: { full_name: user.full_name, role: user.role } }
    });
    if (data.user) {
      staffProfiles.push({ ...user, id: data.user.id });
      console.log(`  Created: ${user.email}`);
    } else if (error?.message?.includes('already')) {
      // User exists, get their ID
      const { data: signInData } = await supabase.auth.signInWithPassword({
        email: user.email,
        password: user.password
      });
      if (signInData?.user) {
        staffProfiles.push({ ...user, id: signInData.user.id });
        console.log(`  Using existing: ${user.email}`);
      }
    }
  }

  // 2. Create demo customer
  console.log('\nCreating demo customer...');
  const { data: customerData } = await supabase.auth.signUp({
    email: 'customer@rushend.demo',
    password: 'demo123456',
    options: { data: { full_name: 'Rahul Sharma', role: 'customer', area: 'Koramangala', language_pref: 'en' } }
  });
  if (customerData?.user) {
    console.log(`  Created: customer@rushend.demo`);
  }

  // 3. Create businesses
  console.log('\nCreating businesses...');

  const hospitalStaff = staffProfiles.find(s => s.email === 'hospital@rushend.demo');
  const restaurantStaff = staffProfiles.find(s => s.email === 'restaurant@rushend.demo');
  const bankStaff = staffProfiles.find(s => s.email === 'bank@rushend.demo');

  const businesses = [
    {
      owner_id: hospitalStaff?.id,
      name: 'City Hospital',
      category: 'hospital',
      address: '123 MG Road, Bangalore',
      area: 'MG Road',
      lat: 12.9756,
      lng: 77.6064
    },
    {
      owner_id: restaurantStaff?.id,
      name: 'Spice Garden Restaurant',
      category: 'restaurant',
      address: '45 5th Block, Koramangala, Bangalore',
      area: 'Koramangala',
      lat: 12.9352,
      lng: 77.6245
    },
    {
      owner_id: bankStaff?.id,
      name: 'State Bank of India - Main Branch',
      category: 'bank',
      address: '78 Residency Road, Bangalore',
      area: 'Residency Road',
      lat: 12.9658,
      lng: 77.6002
    }
  ];

  const createdBusinesses = [];
  for (const biz of businesses) {
    const { data, error } = await supabase
      .from('businesses')
      .insert(biz)
      .select()
      .single();

    if (error) {
      console.log(`  Error creating ${biz.name}: ${error.message}`);
      // Try to get existing
      const { data: existing } = await supabase
        .from('businesses')
        .select()
        .eq('name', biz.name)
        .single();
      if (existing) {
        createdBusinesses.push(existing);
        console.log(`  Using existing: ${biz.name}`);
      }
    } else {
      createdBusinesses.push(data);
      console.log(`  Created: ${biz.name} (QR: ${data.qr_code_id})`);
    }
  }

  // 4. Create counters
  console.log('\nCreating counters...');

  const counters = [
    { business_id: createdBusinesses[0]?.id, name: 'General Counter', identifier: 'G1', is_open: true },
    { business_id: createdBusinesses[0]?.id, name: 'Priority Counter', identifier: 'P1', is_open: true },
    { business_id: createdBusinesses[1]?.id, name: 'Main Counter', identifier: 'M1', is_open: true },
    { business_id: createdBusinesses[1]?.id, name: 'Takeaway Counter', identifier: 'T1', is_open: false },
    { business_id: createdBusinesses[2]?.id, name: 'Token Counter 1', identifier: 'C1', is_open: true },
    { business_id: createdBusinesses[2]?.id, name: 'Token Counter 2', identifier: 'C2', is_open: true },
  ];

  const createdCounters = [];
  for (const counter of counters) {
    if (!counter.business_id) continue;
    const { data, error } = await supabase.from('counters').insert(counter).select().single();
    if (data) {
      createdCounters.push(data);
      console.log(`  Created: ${counter.name}`);
    }
  }

  // 5. Create queues
  console.log('\nCreating queues...');

  const queues = [
    { business_id: createdBusinesses[0]?.id, service_name: 'General OPD', service_code: 'GOPD', avg_service_time_mins: 15, counter_id: createdCounters[0]?.id },
    { business_id: createdBusinesses[0]?.id, service_name: 'Specialist Consultation', service_code: 'SPCL', avg_service_time_mins: 20, counter_id: createdCounters[1]?.id },
    { business_id: createdBusinesses[1]?.id, service_name: 'Dine In', service_code: 'DINE', avg_service_time_mins: 8, counter_id: createdCounters[2]?.id },
    { business_id: createdBusinesses[1]?.id, service_name: 'Takeaway', service_code: 'TAKE', avg_service_time_mins: 5, counter_id: createdCounters[3]?.id },
    { business_id: createdBusinesses[2]?.id, service_name: 'Banking Services', service_code: 'BANK', avg_service_time_mins: 12, counter_id: createdCounters[4]?.id },
  ];

  const createdQueues = [];
  for (const queue of queues) {
    if (!queue.business_id) continue;
    const { data, error } = await supabase.from('queues').insert(queue).select().single();
    if (data) {
      createdQueues.push(data);
      console.log(`  Created: ${queue.service_name}`);
    }
  }

  // 6. Generate historical service logs
  console.log('\nGenerating historical service logs...');

  const dayOfWeek = new Date().getDay();
  const hourOfDay = new Date().getHours();

  let logCount = 0;
  for (const queue of createdQueues) {
    // Generate 20-30 logs per queue
    const numLogs = 20 + Math.floor(Math.random() * 10);

    for (let i = 0; i < numLogs; i++) {
      const logHour = 8 + Math.floor(Math.random() * 12); // 8am to 8pm
      const logDay = Math.floor(Math.random() * 7);
      const queueLength = Math.floor(Math.random() * 15);
      const position = 1 + Math.floor(Math.random() * Math.max(1, queueLength));
      const baseWait = position * (queue.avg_service_time_mins || 10);
      const actualWait = baseWait + Math.floor(Math.random() * 10) - 5;

      const { error } = await supabase.from('historical_service_logs').insert({
        queue_id: queue.id,
        day_of_week: logDay,
        hour_of_day: logHour,
        queue_length_at_join: queueLength,
        position_at_join: position,
        predicted_wait_mins: baseWait,
        actual_wait_mins: Math.max(1, actualWait),
        is_priority: Math.random() < 0.15
      });

      if (!error) logCount++;
    }
  }
  console.log(`  Created ${logCount} historical logs`);

  // 7. Create sample ratings
  console.log('\nCreating sample ratings...');

  const ratings = [
    { business_id: createdBusinesses[0]?.id, stars: 4, comment: 'Good service, minimal wait' },
    { business_id: createdBusinesses[0]?.id, stars: 5, comment: 'Excellent care!' },
    { business_id: createdBusinesses[1]?.id, stars: 4, comment: 'Great food, worth the wait' },
    { business_id: createdBusinesses[1]?.id, stars: 5, comment: 'Best restaurant in the area!' },
    { business_id: createdBusinesses[2]?.id, stars: 3, comment: 'Average service' },
    { business_id: createdBusinesses[2]?.id, stars: 4, comment: 'Efficient token system' },
  ];

  for (const rating of ratings) {
    if (!rating.business_id) continue;
    await supabase.from('ratings').insert({
      ...rating,
      customer_id: customerData?.user?.id
    }).select().single();
  }
  console.log(`  Created ${ratings.length} ratings`);

  console.log('\n✅ Seeding complete!\n');
  console.log('Demo Credentials:');
  console.log('  Staff (Hospital): hospital@rushend.demo / demo123456');
  console.log('  Staff (Restaurant): restaurant@rushend.demo / demo123456');
  console.log('  Staff (Bank): bank@rushend.demo / demo123456');
  console.log('  Customer: customer@rushend.demo / demo123456');
  console.log('\nBusiness QR Codes:');
  createdBusinesses.forEach(b => {
    console.log(`  ${b.name}: ${process.env.FRONTEND_URL || 'http://localhost:3000'}/join/${b.qr_code_id}`);
  });
}

seed().catch(console.error);
