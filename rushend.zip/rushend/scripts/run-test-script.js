﻿require('dotenv').config();
const { createClient } = require('@supabase/supabase-js');

const supabaseUrl = 'https://tqucvtjdpxnzvdxxzret.supabase.co';
const supabaseKey = process.env.SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

async function check() {
  const { data, error } = await supabase.from('businesses').select('id, name').limit(1);
  if (error) {
    console.error('Check failed:', error.message);
  } else {
    console.log('Success! Connected to database. Data:', data);
  }
}

check();
