﻿
const { Client } = require('pg');
const fs = require('fs');
const path = require('path');

async function retryDirectPort() {
  const actualCnString = 'postgresql://postgres:RucshEnd@04@db.tqucvtjdpxnzvdxxzret.supabase.co:5432/postgres';

  const client = new Client({
    connectionString: actualCnString,
    ssl: { rejectUnauthorized: false }
  });

  try {
    console.log('Connecting to PostgreSQL database directly on port 5432...');
    await client.connect();

    const sqlPath = path.join(__dirname, '..', 'supabase', 'combined_migrations.sql');
    let sql = fs.readFileSync(sqlPath, 'utf8');

    // Remove the realtime publication commands as they fail if already exists
    sql = sql.replace(/DROP PUBLICATION IF EXISTS supabase_realtime;/g, '');
    sql = sql.replace(/CREATE PUBLICATION supabase_realtime FOR TABLE tokens, queues, counters, businesses;/g, '');
    sql = sql.replace(/ALTER PUBLICATION supabase_realtime ADD TABLE tokens;/g, '');
    sql = sql.replace(/ALTER PUBLICATION supabase_realtime ADD TABLE queues;/g, '');
    sql = sql.replace(/ALTER PUBLICATION supabase_realtime ADD TABLE counters;/g, '');
    sql = sql.replace(/ALTER PUBLICATION supabase_realtime ADD TABLE businesses;/g, '');

    console.log('Running modified combined migration SQL...');
    await client.query(sql);

    console.log('✅ Migrations applied successfully!');
  } catch (err) {
    console.error('❌ Error executing migrations:', err.message);
  } finally {
    await client.end();
  }
}

retryDirectPort();
