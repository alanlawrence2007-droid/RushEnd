/**
 * Run migrations directly on hosted Supabase using the REST API
 */

require('dotenv').config();

const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!SUPABASE_URL || !SUPABASE_SERVICE_KEY) {
  console.error('Missing Supabase credentials in .env');
  process.exit(1);
}

const fs = require('fs');
const path = require('path');

async function runMigration(sql, description) {
  try {
    const response = await fetch(`${SUPABASE_URL}/rest/v1/rpc/exec_sql`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
        'apikey': SUPABASE_SERVICE_KEY,
        'Prefer': 'return=minimal'
      },
      body: JSON.stringify({ query: sql })
    });

    if (!response.ok) {
      const text = await response.text();
      // Try direct SQL execution via PostgREST
      console.log(`  Trying direct SQL for: ${description}`);
      return runDirectSQL(sql);
    }

    console.log(`  ✅ ${description}`);
    return true;
  } catch (error) {
    console.log(`  Trying direct SQL for: ${description}`);
    return runDirectSQL(sql);
  }
}

async function runDirectSQL(sql) {
  try {
    // Split into individual statements
    const statements = sql.split(';').map(s => s.trim()).filter(s => s.length > 0);

    for (const stmt of statements) {
      if (stmt.startsWith('--') || stmt.startsWith('/*')) continue;

      // Use the query parameter for raw SQL
      const response = await fetch(`${SUPABASE_URL}/rest/v1/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'apikey': SUPABASE_SERVICE_KEY,
          'Prefer': 'return=minimal',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ query: stmt })
      });

      if (!response.ok) {
        const text = await response.text();
        // Some statements might fail if they already exist, that's OK
        if (!text.includes('already exists') && !text.includes('duplicate')) {
          console.warn(`    Warning: ${text.substring(0, 200)}`);
        }
      }
    }
    return true;
  } catch (error) {
    console.error(`    Error: ${error.message}`);
    return false;
  }
}

async function main() {
  console.log('Running migrations on hosted Supabase...\n');

  // Read migration files
  const migrationsDir = path.join(__dirname, '..', 'supabase', 'migrations');
  const files = fs.readdirSync(migrationsDir).sort();

  for (const file of files) {
    if (!file.endsWith('.sql')) continue;

    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    console.log(`\nRunning: ${file}`);
    await runMigration(sql, file);
  }

  console.log('\n✅ All migrations attempted!');
  console.log('Note: Some statements may have warnings if tables already exist.');
}

main().catch(console.error);