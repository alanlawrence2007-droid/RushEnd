# RushEnd - Real-time AI-Powered Queue Management System

A digital queue management system for India that lets people join queues remotely, see AI-predicted wait times, and only return to the venue when their turn is near.

## Features

- **Remote Queue Joining**: Scan QR code or search for businesses to join queues remotely
- **AI Wait-Time Prediction**: ML model predicts wait times based on position, time, day, and live queue data
- **Real-time Updates**: WebSocket-based live position and status updates
- **Priority Token Support**: Staff can mark priority tokens for faster service
- **Multi-language Support**: Language preference stored per user
- **Analytics Dashboard**: Business owners get hourly analytics and peak hour identification
- **Rating System**: Post-service ratings with average business ratings

## Tech Stack

- **Backend**: Supabase (PostgreSQL, Auth, Realtime) + Node.js API layer
- **AI/ML**: Python FastAPI service with scikit-learn
- **Frontend**: Next.js (separate team)

## Project Structure

```
rushend/
├── supabase/
│   ├── migrations/        # Database schema migrations
│   └── functions/         # Edge Functions (Deno)
├── api/                   # Node.js API layer
│   ├── src/
│   │   ├── routes/        # API endpoints
│   │   ├── middleware/    # Auth, validation
│   │   ├── services/      # Business logic
│   │   └── utils/         # Helpers
│   └── tests/
├── ai-service/            # Python ML microservice
│   ├── app/
│   ├── models/
│   └── scripts/
├── docs/
│   └── API_REFERENCE.md
└── scripts/               # Utility scripts
```

## Setup

### Prerequisites

- Node.js 18+
- Python 3.9+ (for AI service)
- Supabase account (free tier works)

### 1. Create Supabase Project

1. Go to https://supabase.com/dashboard
2. Create a new project
3. Note down:
   - Project URL
   - Anon Key
   - Service Role Key
   - Database connection string

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your Supabase credentials
```

### 3. Run Migrations

```bash
# Link to your Supabase project
npx supabase link --project-ref your-project-ref

# Push migrations
npx supabase db push
```

### 4. Install Dependencies

```bash
# Node.js dependencies
npm install

# Python dependencies
cd ai-service
pip install -r requirements.txt
```

### 5. Run Services

```bash
# API server
npm run dev

# AI service (separate terminal)
cd ai-service
uvicorn app.main:app --reload
```

## Development

### Running Tests

```bash
npm test
```

### API Documentation

See [docs/API_REFERENCE.md](docs/API_REFERENCE.md) for complete endpoint documentation.

## Deployment

### Supabase

```bash
# Deploy Edge Functions
npx supabase functions deploy

# Migrations are auto-applied via db push
```

### AI Service

Deploy to any Python hosting (Railway, Render, Fly.io, etc.)

## License

MIT
