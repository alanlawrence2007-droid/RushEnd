# RushEnd API Reference

Complete API documentation for the RushEnd queue management system. All endpoints are JSON-based.

**Base URL**: `https://rushend-api.onrender.com`

**Authentication**: Most endpoints require a Bearer token in the Authorization header:
```
Authorization: Bearer <your-jwt-token>
```

---

## Table of Contents

1. [Authentication](#authentication)
2. [Business Management](#business-management)
3. [Queue Management](#queue-management)
4. [Token Operations](#token-operations)
5. [Ratings](#ratings)
6. [AI Predictions](#ai-predictions)
7. [Shared Links](#shared-links)
8. [Realtime](#realtime)

---

## Authentication

### POST /auth/signup

Create a new user account (customer or staff).

**Auth Required**: No

**Request Body**:
```json
{
  "email": "user@example.com",
  "password": "password123",
  "full_name": "John Doe",
  "role": "customer",
  "area": "Koramangala",
  "phone": "+91-9876543210",
  "language_pref": "en"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| email | string | Yes | Valid email address |
| password | string | Yes | Min 6 characters |
| full_name | string | Yes | User's full name |
| role | string | Yes | "customer" or "staff" |
| area | string | No | Location/area |
| phone | string | No | Phone number |
| language_pref | string | No | Language code (default: "en") |

**Response** (201):
```json
{
  "message": "User created successfully",
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    ...
  },
  "session": {
    "access_token": "eyJhbGci...",
    "refresh_token": "...",
    "expires_in": 3600
  }
}
```

---

### POST /auth/login

Authenticate and get access token.

**Auth Required**: No

**Request Body**:
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response** (200):
```json
{
  "message": "Login successful",
  "user": {
    "id": "uuid",
    "email": "user@example.com"
  },
  "session": {
    "access_token": "eyJhbGci...",
    "refresh_token": "...",
    "expires_in": 3600
  }
}
```

---

### GET /auth/me

Get current authenticated user's profile.

**Auth Required**: Yes

**Response** (200):
```json
{
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "full_name": "John Doe",
    "role": "customer",
    "area": "Koramangala",
    "phone": "+91-9876543210",
    "language_pref": "en",
    "created_at": "2024-09-01T10:00:00Z"
  }
}
```

---

### PATCH /auth/me

Update current user's profile.

**Auth Required**: Yes

**Request Body**:
```json
{
  "full_name": "Jane Doe",
  "area": "Indiranagar",
  "language_pref": "hi"
}
```

**Response** (200):
```json
{
  "message": "Profile updated",
  "profile": { ... }
}
```

---

### POST /auth/logout

Sign out current user.

**Auth Required**: Yes

**Response** (200):
```json
{
  "message": "Logged out successfully"
}
```

---

## Business Management

### POST /business

Create a new business (staff only). Automatically generates QR code.

**Auth Required**: Yes (staff role)

**Request Body**:
```json
{
  "name": "City Hospital",
  "category": "hospital",
  "address": "123 MG Road, Bangalore",
  "area": "MG Road",
  "lat": 12.9756,
  "lng": 77.6064
}
```

| Category | Description |
|----------|-------------|
| hospital | Medical facilities |
| restaurant | Food establishments |
| bank | Banking services |
| government | Government offices |
| other | Other businesses |

**Response** (201):
```json
{
  "business": {
    "id": "uuid",
    "name": "City Hospital",
    "category": "hospital",
    "qr_code_id": "a1b2c3d4e5f6",
    "avg_rating": null,
    ...
  },
  "qr_code": {
    "url": "http://localhost:3000/join/a1b2c3d4e5f6",
    "data_url": "data:image/png;base64,..."
  }
}
```

---

### GET /business/:id

Get business details with counters and queues.

**Auth Required**: No

**Response** (200):
```json
{
  "id": "uuid",
  "name": "City Hospital",
  "category": "hospital",
  "address": "123 MG Road, Bangalore",
  "qr_code_id": "a1b2c3d4e5f6",
  "avg_rating": 4.5,
  "counters": [
    { "id": "uuid", "name": "Counter 1", "is_open": true }
  ],
  "queues": [
    { "id": "uuid", "service_name": "General OPD", "avg_service_time_mins": 15 }
  ]
}
```

---

### GET /businesses

Search for businesses.

**Auth Required**: No

**Query Parameters**:
| Param | Type | Description |
|-------|------|-------------|
| area | string | Filter by area (partial match) |
| category | string | Filter by category |
| search | string | Search by name (partial match) |
| limit | number | Results per page (default: 20) |
| offset | number | Pagination offset (default: 0) |

**Response** (200):
```json
{
  "businesses": [
    {
      "id": "uuid",
      "name": "City Hospital",
      "category": "hospital",
      "area": "MG Road",
      "avg_rating": 4.5
    }
  ],
  "total": 15,
  "limit": 20,
  "offset": 0
}
```

---

### PATCH /business/:id

Update business (owner only).

**Auth Required**: Yes (owner)

**Request Body**:
```json
{
  "name": "Updated Name",
  "is_active": false
}
```

---

### POST /business/:id/counter

Create a new service counter.

**Auth Required**: Yes (owner)

**Request Body**:
```json
{
  "name": "Counter 1",
  "identifier": "C1"
}
```

**Response** (201):
```json
{
  "id": "uuid",
  "business_id": "uuid",
  "name": "Counter 1",
  "identifier": "C1",
  "is_open": false
}
```

---

### PATCH /counter/:id

Update counter (toggle open/closed).

**Auth Required**: Yes (owner)

**Request Body**:
```json
{
  "is_open": true,
  "name": "Updated Name"
}
```

---

### POST /business/:id/queue

Create a new queue/service.

**Auth Required**: Yes (owner)

**Request Body**:
```json
{
  "service_name": "General OPD",
  "service_code": "GOPD",
  "avg_service_time_mins": 15,
  "counter_id": "uuid"
}
```

**Response** (201):
```json
{
  "id": "uuid",
  "business_id": "uuid",
  "service_name": "General OPD",
  "avg_service_time_mins": 15
}
```

---

### GET /business/:id/analytics

Get business analytics (owner only). Returns hourly queue data and peak hours.

**Auth Required**: Yes (owner)

**Response** (200):
```json
{
  "today": "2024-09-01",
  "hourly_buckets": [
    { "hour": 0, "count": 0, "avg_queue_length": 0 },
    { "hour": 9, "count": 15, "avg_queue_length": 8 },
    { "hour": 10, "count": 25, "avg_queue_length": 12 }
  ],
  "peak_hours": [10, 11, 18],
  "stats": {
    "total_tokens_today": 87,
    "current_hour_queue": 5,
    "current_hour": 14
  }
}
```

---

## Queue Operations

### POST /queue/:id/join

Join a queue. Assigns next token number and returns AI-predicted wait time.

**Auth Required**: Yes

**Request Body**:
```json
{
  "is_priority": false
}
```

**Response** (201):
```json
{
  "token": {
    "id": "uuid",
    "queue_id": "uuid",
    "token_number": 42,
    "status": "waiting",
    "is_priority": false,
    "predicted_wait_mins": 35,
    "position_at_join": 5,
    "joined_at": "2024-09-01T10:30:00Z"
  },
  "position": 5,
  "predicted_wait_mins": 35
}
```

---

### GET /queue/:id/live

Get live queue status.

**Auth Required**: No

**Response** (200):
```json
{
  "queue_id": "uuid",
  "queue_name": "General OPD",
  "business_name": "City Hospital",
  "waiting_count": 8,
  "open_counters": 2,
  "counters": [
    { "id": "uuid", "name": "Counter 1", "is_open": true }
  ],
  "avg_wait_mins": 25,
  "currently_serving": [
    { "token_number": 38, "called_at": "2024-09-01T10:25:00Z" }
  ]
}
```

---

## Token Operations

### GET /token/:id

Get token status with live position recalculated.

**Auth Required**: No

**Response** (200):
```json
{
  "token": {
    "id": "uuid",
    "token_number": 42,
    "status": "waiting",
    "is_priority": false,
    "predicted_wait_mins": 28,
    "joined_at": "2024-09-01T10:30:00Z"
  },
  "position": 3,
  "queue": {
    "service_name": "General OPD",
    "business_name": "City Hospital"
  }
}
```

---

### POST /token/manual

Staff-only: Create a manual walk-in token.

**Auth Required**: Yes (staff)

**Request Body**:
```json
{
  "queue_id": "uuid",
  "full_name": "Walk-in Customer",
  "phone": "+91-9876543210",
  "is_priority": false
}
```

**Response** (201):
```json
{
  "token": {
    "id": "uuid",
    "token_number": 43,
    "status": "waiting",
    "is_manual_entry": true
  },
  "position": 4,
  "predicted_wait_mins": 30
}
```

---

### PATCH /token/:id/priority

Staff-only: Toggle priority status.

**Auth Required**: Yes (staff)

**Request Body**:
```json
{
  "is_priority": true
}
```

---

### POST /token/:id/call-next

Staff-only: Call the next token to be served. Respects priority ordering.

**Auth Required**: Yes (staff)

**Note**: The `:id` here is the **queue_id**, not token_id.

**Response** (200):
```json
{
  "id": "uuid",
  "token_number": 42,
  "status": "called",
  "called_at": "2024-09-01T11:05:00Z"
}
```

---

### POST /token/:id/serve

Mark token as served. Automatically logs to historical_service_logs.

**Auth Required**: Yes (staff)

**Response** (200):
```json
{
  "token": {
    "id": "uuid",
    "status": "served",
    "served_at": "2024-09-01T11:15:00Z",
    "actual_wait_mins": 45
  },
  "actual_wait_mins": 45
}
```

---

### POST /token/:id/skip

Mark token as skipped.

**Auth Required**: Yes (staff)

---

### POST /token/:id/leave

Customer leaves the queue.

**Auth Required**: Yes (token owner)

---

### POST /token/:id/share

Generate a public shareable link for token status.

**Auth Required**: Yes (token owner)

**Response** (200):
```json
{
  "share_url": "http://localhost:3000/shared/abc123xyz",
  "share_code": "abc123xyz",
  "expires_at": "2024-09-02T10:30:00Z"
}
```

---

## Ratings

### POST /rating

Submit a rating for a served token.

**Auth Required**: Yes

**Request Body**:
```json
{
  "business_id": "uuid",
  "token_id": "uuid",
  "stars": 4,
  "comment": "Good service!"
}
```

**Response** (201):
```json
{
  "id": "uuid",
  "business_id": "uuid",
  "stars": 4,
  "comment": "Good service!",
  "created_at": "2024-09-01T11:20:00Z"
}
```

---

### GET /rating/business/:id

Get ratings for a business.

**Auth Required**: No

---

### GET /rating/my

Get current user's ratings.

**Auth Required**: Yes

---

## AI Predictions

### POST /predict/wait-time

Get AI-predicted wait time.

**Auth Required**: No

**Request Body**:
```json
{
  "queue_position": 5,
  "hour_of_day": 14,
  "day_of_week": 1,
  "current_queue_length": 8,
  "counter_avg_service_time": 10
}
```

**Response** (200):
```json
{
  "predicted_wait_mins": 42,
  "confidence_tier": "high",
  "model": "gradient_boosting"
}
```

---

### POST /predict/delay-check

Check if a counter is running behind schedule.

**Auth Required**: No

**Request Body**:
```json
{
  "queue_id": "uuid",
  "counter_id": "uuid"
}
```

**Response** (200):
```json
{
  "delayed": false,
  "delay_multiplier": 1.0,
  "counters_checked": 1,
  "message": "Service is on schedule"
}
```

---

## Shared Links

### GET /shared/:share_code

Public endpoint to view token status. No authentication required.

**Auth Required**: No

**Response** (200):
```json
{
  "token": {
    "id": "uuid",
    "token_number": 42,
    "status": "waiting",
    "predicted_wait_mins": 28
  },
  "position": 3,
  "queue": {
    "service_name": "General OPD",
    "business_name": "City Hospital"
  },
  "share_expires_at": "2024-09-02T10:30:00Z"
}
```

---

## Realtime

Supabase Realtime channels for live updates. Connect via WebSocket.

### Channel: `queue:{queue_id}`

Events:
- `token_joined` - New token added
- `token_called` - Token called to counter
- `token_served` - Token marked served
- `token_skipped` - Token skipped
- `priority_changed` - Priority status changed

### Channel: `business:{business_id}`

Events:
- `token_called` - Token called

**Example (JavaScript)**:
```javascript
import { createClient } from '@supabase/supabase-js'

const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY)

const channel = supabase
  .channel('queue:queue-id-here')
  .on('broadcast', { event: 'token_joined' }, (payload) => {
    console.log('New token:', payload)
  })
  .subscribe()
```

---

## Error Responses

All errors follow this format:

```json
{
  "error": "Error message here",
  "details": "Additional details (dev mode only)"
}
```

Common status codes:
- 400 - Bad Request (validation error)
- 401 - Unauthorized (missing/invalid token)
- 403 - Forbidden (insufficient permissions)
- 404 - Not Found
- 410 - Gone (expired share link)
- 500 - Internal Server Error

---

## Testing Examples

### Complete Flow: Customer joins queue

```bash
# 1. Signup customer
curl -X POST https://rushend-api.onrender.com/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123","full_name":"Test User","role":"customer"}'

# 2. Login (get token)
curl -X POST https://rushend-api.onrender.com/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'

# 3. Search for businesses
curl https://rushend-api.onrender.com/businesses?area=MG%20Road

# 4. Get queue details
curl https://rushend-api.onrender.com/business/{business_id}

# 5. Join queue
curl -X POST https://rushend-api.onrender.com/queue/{queue_id}/join \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{}'

# 6. Check token status
curl https://rushend-api.onrender.com/token/{token_id}
```

---

*Last updated: September 2024*
