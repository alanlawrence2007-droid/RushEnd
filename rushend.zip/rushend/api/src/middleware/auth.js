/**
 * Authentication middleware
 * Verifies JWT token from Supabase Auth
 */

const getAuthUser = async (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Missing or invalid authorization header' });
  }

  const token = authHeader.split(' ')[1];
  const supabase = req.app.locals.supabase;

  try {
    const { data: { user }, error } = await supabase.auth.getUser(token);

    if (error || !user) {
      return res.status(401).json({ error: 'Invalid or expired token' });
    }

    req.user = user;
    req.token = token;
    next();
  } catch (err) {
    console.error('Auth middleware error:', err);
    return res.status(401).json({ error: 'Authentication failed' });
  }
};

/**
 * Optional auth - sets user if token present, but doesn't require it
 */
const optionalAuth = async (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next();
  }

  const token = authHeader.split(' ')[1];
  const supabase = req.app.locals.supabase;

  try {
    const { data: { user }, error } = await supabase.auth.getUser(token);
    if (!error && user) {
      req.user = user;
      req.token = token;
    }
  } catch (err) {
    // Silently continue without user
  }

  next();
};

/**
 * Require staff role
 */
const requireStaff = async (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const supabaseAdmin = req.app.locals.supabaseAdmin;

  const { data: profile, error } = await supabaseAdmin
    .from('profiles')
    .select('role')
    .eq('user_id', req.user.id)
    .single();

  if (error || !profile || profile.role !== 'staff') {
    return res.status(403).json({ error: 'Staff access required' });
  }

  req.user.role = 'staff';
  next();
};

/**
 * Get user profile from database
 */
const getUserProfile = async (req, res, next) => {
  if (!req.user) {
    return next();
  }

  const supabaseAdmin = req.app.locals.supabaseAdmin;

  const { data: profile, error } = await supabaseAdmin
    .from('profiles')
    .select('*')
    .eq('user_id', req.user.id)
    .single();

  if (!error && profile) {
    req.user.profile = profile;
  }

  next();
};

module.exports = {
  getAuthUser,
  optionalAuth,
  requireStaff,
  getUserProfile
};
