const express = require('express');
const router = express.Router({ mergeParams: true });
const QRCode = require('qrcode');
const { getAuthUser, requireStaff, getUserProfile } = require('../middleware/auth');
const { body, validationResult, query } = require('express-validator');

/**
 * POST /business
 * Create a new business (staff only)
 * Body: { name, category, address, area?, lat?, lng? }
 */
router.post('/',
  getAuthUser,
  requireStaff,
  [
    body('name').notEmpty().withMessage('Business name required'),
    body('category').isIn(['hospital', 'restaurant', 'bank', 'government', 'other']).withMessage('Invalid category'),
    body('address').notEmpty().withMessage('Address required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, category, address, area, lat, lng } = req.body;
    const supabaseAdmin = req.app.locals.supabaseAdmin;
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

    try {
      // Create business
      const { data: business, error } = await supabaseAdmin
        .from('businesses')
        .insert({
          owner_id: req.user.id,
          name,
          category,
          address,
          area: area || null,
          lat: lat || null,
          lng: lng || null
        })
        .select()
        .single();

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      // Generate QR code
      const joinUrl = `${frontendUrl}/join/${business.qr_code_id}`;
      const qrDataUrl = await QRCode.toDataURL(joinUrl, {
        width: 300,
        margin: 2
      });

      res.status(201).json({
        business,
        qr_code: {
          url: joinUrl,
          data_url: qrDataUrl
        }
      });
    } catch (err) {
      console.error('Create business error:', err);
      res.status(500).json({ error: 'Failed to create business' });
    }
  }
);

/**
 * GET /business/:id
 * Get business by ID
 */
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  const supabase = req.app.locals.supabase;

  try {
    const { data: business, error } = await supabase
      .from('businesses')
      .select(`
        *,
        counters (*),
        queues (*)
      `)
      .eq('id', id)
      .single();

    if (error || !business) {
      return res.status(404).json({ error: 'Business not found' });
    }

    res.json(business);
  } catch (err) {
    console.error('Get business error:', err);
    res.status(500).json({ error: 'Failed to get business' });
  }
});

/**
 * GET /businesses
 * Search businesses
 * Query params: area?, category?, search?
 */
router.get('/',
  async (req, res) => {
    const { area, category, search, limit = 20, offset = 0 } = req.query;
    const supabase = req.app.locals.supabase;

    try {
      let query = supabase
        .from('businesses')
        .select('*', { count: 'exact' })
        .eq('is_active', true)
        .order('name');

      // Filter by category
      if (category) {
        query = query.eq('category', category);
      }

      // Filter by area (case-insensitive partial match)
      if (area) {
        query = query.ilike('area', `%${area}%`);
      }

      // Search by name (case-insensitive partial match)
      if (search) {
        query = query.ilike('name', `%${search}%`);
      }

      // Pagination
      query = query.range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1);

      const { data: businesses, error, count } = await query;

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      res.json({
        businesses,
        total: count,
        limit: parseInt(limit),
        offset: parseInt(offset)
      });
    } catch (err) {
      console.error('Search businesses error:', err);
      res.status(500).json({ error: 'Failed to search businesses' });
    }
  }
);

/**
 * PATCH /business/:id
 * Update business (owner only)
 */
router.patch('/:id',
  getAuthUser,
  async (req, res) => {
    const { id } = req.params;
    const { name, category, address, area, lat, lng, is_active } = req.body;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Check ownership
      const { data: existing, error: checkError } = await supabaseAdmin
        .from('businesses')
        .select('owner_id')
        .eq('id', id)
        .single();

      if (checkError || !existing) {
        return res.status(404).json({ error: 'Business not found' });
      }

      if (existing.owner_id !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized to update this business' });
      }

      // Build updates
      const updates = { updated_at: new Date().toISOString() };
      if (name) updates.name = name;
      if (category) updates.category = category;
      if (address) updates.address = address;
      if (area !== undefined) updates.area = area;
      if (lat !== undefined) updates.lat = lat;
      if (lng !== undefined) updates.lng = lng;
      if (is_active !== undefined) updates.is_active = is_active;

      const { data, error } = await supabaseAdmin
        .from('businesses')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      res.json({ message: 'Business updated', business: data });
    } catch (err) {
      console.error('Update business error:', err);
      res.status(500).json({ error: 'Failed to update business' });
    }
  }
);

/**
 * POST /business/:id/counter
 * Create a new counter for a business (owner only)
 * Body: { name, identifier? }
 */
router.post('/:id/counter',
  getAuthUser,
  [
    body('name').notEmpty().withMessage('Counter name required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { name, identifier } = req.body;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Check ownership
      const { data: business, error: checkError } = await supabaseAdmin
        .from('businesses')
        .select('owner_id')
        .eq('id', id)
        .single();

      if (checkError || !business) {
        return res.status(404).json({ error: 'Business not found' });
      }

      if (business.owner_id !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      const { data: counter, error } = await supabaseAdmin
        .from('counters')
        .insert({
          business_id: id,
          name,
          identifier: identifier || name
        })
        .select()
        .single();

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      res.status(201).json(counter);
    } catch (err) {
      console.error('Create counter error:', err);
      res.status(500).json({ error: 'Failed to create counter' });
    }
  }
);

/**
 * PATCH /counter/:id
 * Update counter (toggle open/closed)
 * Body: { is_open, name? }
 */
router.patch('/counter/:id',
  getAuthUser,
  async (req, res) => {
    const { id } = req.params;
    const { is_open, name } = req.body;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Get counter and check ownership
      const { data: counter, error: fetchError } = await supabaseAdmin
        .from('counters')
        .select('*, businesses!inner(owner_id)')
        .eq('id', id)
        .single();

      if (fetchError || !counter) {
        return res.status(404).json({ error: 'Counter not found' });
      }

      if (counter.businesses.owner_id !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      const updates = { updated_at: new Date().toISOString() };
      if (is_open !== undefined) updates.is_open = is_open;
      if (name) updates.name = name;

      const { data, error } = await supabaseAdmin
        .from('counters')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      res.json(data);
    } catch (err) {
      console.error('Update counter error:', err);
      res.status(500).json({ error: 'Failed to update counter' });
    }
  }
);

/**
 * POST /business/:id/queue
 * Create a new queue/service for a business (owner only)
 * Body: { service_name, service_code?, avg_service_time_mins?, counter_id? }
 */
router.post('/:id/queue',
  getAuthUser,
  [
    body('service_name').notEmpty().withMessage('Service name required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { service_name, service_code, avg_service_time_mins, counter_id } = req.body;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Check ownership
      const { data: business, error: checkError } = await supabaseAdmin
        .from('businesses')
        .select('owner_id')
        .eq('id', id)
        .single();

      if (checkError || !business) {
        return res.status(404).json({ error: 'Business not found' });
      }

      if (business.owner_id !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      const { data: queue, error } = await supabaseAdmin
        .from('queues')
        .insert({
          business_id: id,
          service_name,
          service_code: service_code || null,
          avg_service_time_mins: avg_service_time_mins || 5,
          counter_id: counter_id || null
        })
        .select()
        .single();

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      res.status(201).json(queue);
    } catch (err) {
      console.error('Create queue error:', err);
      res.status(500).json({ error: 'Failed to create queue' });
    }
  }
);

/**
 * GET /business/:id/analytics
 * Get analytics for a business (owner only)
 * Returns hourly queue-length buckets for today + identified peak hours
 */
router.get('/:id/analytics',
  getAuthUser,
  async (req, res) => {
    const { id } = req.params;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Check ownership
      const { data: business, error: checkError } = await supabaseAdmin
        .from('businesses')
        .select('owner_id')
        .eq('id', id)
        .single();

      if (checkError || !business) {
        return res.status(404).json({ error: 'Business not found' });
      }

      if (business.owner_id !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      // Get today's tokens grouped by hour
      const today = new Date().toISOString().split('T')[0];

      const { data: todayTokens, error: tokenError } = await supabaseAdmin
        .from('tokens')
        .select('joined_at, queue_id')
        .eq('joined_at::date', today)
        .in('queue_id', (
          await supabaseAdmin.from('queues').select('id').eq('business_id', id)
        ).data.map(q => q.id));

      // Get historical data for peak hour identification
      const { data: historicalData } = await supabaseAdmin
        .from('historical_service_logs')
        .select('hour_of_day, day_of_week, queue_length_at_join')
        .in('queue_id', (
          await supabaseAdmin.from('queues').select('id').eq('business_id', id)
        ).data?.map(q => q.id) || []);

      // Process hourly buckets
      const hourlyBuckets = {};
      for (let i = 0; i < 24; i++) {
        hourlyBuckets[i] = { hour: i, count: 0, avg_queue_length: 0 };
      }

      // Fill today's data
      if (todayTokens) {
        todayTokens.forEach(token => {
          const hour = new Date(token.joined_at).getHours();
          hourlyBuckets[hour].count++;
        });
      }

      // Calculate average queue lengths from historical data
      const hourAggregates = {};
      if (historicalData) {
        historicalData.forEach(log => {
          if (!hourAggregates[log.hour_of_day]) {
            hourAggregates[log.hour_of_day] = { total: 0, count: 0 };
          }
          hourAggregates[log.hour_of_day].total += log.queue_length_at_join || 0;
          hourAggregates[log.hour_of_day].count++;
        });

        Object.keys(hourAggregates).forEach(hour => {
          const agg = hourAggregates[hour];
          hourlyBuckets[hour].avg_queue_length = agg.count > 0
            ? Math.round(agg.total / agg.count)
            : 0;
        });
      }

      // Identify peak hours (top 3 by historical average)
      const sortedHours = Object.values(hourlyBuckets)
        .filter(h => h.avg_queue_length > 0)
        .sort((a, b) => b.avg_queue_length - a.avg_queue_length);

      const peakHours = sortedHours.slice(0, 3).map(h => h.hour);

      // Stats
      const totalToday = Object.values(hourlyBuckets).reduce((sum, h) => sum + h.count, 0);
      const currentHour = new Date().getHours();
      const currentQueueLength = hourlyBuckets[currentHour].count;

      res.json({
        today: today,
        hourly_buckets: Object.values(hourlyBuckets),
        peak_hours: peakHours,
        stats: {
          total_tokens_today: totalToday,
          current_hour_queue: currentQueueLength,
          current_hour: currentHour
        }
      });
    } catch (err) {
      console.error('Analytics error:', err);
      res.status(500).json({ error: 'Failed to get analytics' });
    }
  }
);

module.exports = router;
