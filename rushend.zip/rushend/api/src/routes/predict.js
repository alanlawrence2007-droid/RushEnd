const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');

/**
 * POST /predict/wait-time
 * Get AI-predicted wait time
 * Body: { queue_position, hour_of_day, day_of_week, current_queue_length, counter_avg_service_time }
 */
router.post('/wait-time',
  [
    body('queue_position').isInt({ min: 1 }).withMessage('queue_position must be >= 1'),
    body('hour_of_day').isInt({ min: 0, max: 23 }).withMessage('hour_of_day must be 0-23'),
    body('day_of_week').isInt({ min: 0, max: 6 }).withMessage('day_of_week must be 0-6'),
    body('current_queue_length').isInt({ min: 0 }).withMessage('current_queue_length must be >= 0'),
    body('counter_avg_service_time').isInt({ min: 1 }).withMessage('counter_avg_service_time required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { queue_position, hour_of_day, day_of_week, current_queue_length, counter_avg_service_time } = req.body;

    try {
      // Try AI service first
      if (process.env.AI_SERVICE_ENABLED === 'true') {
        try {
          const aiResponse = await fetch(`${process.env.AI_SERVICE_URL}/predict/wait-time`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(req.body)
          });

          if (aiResponse.ok) {
            const aiData = await aiResponse.json();
            return res.json(aiData);
          }
        } catch (aiErr) {
          console.warn('AI service unavailable, using fallback');
        }
      }

      // Fallback: Simple heuristic calculation
      let baseWait = queue_position * counter_avg_service_time;

      // Apply time-of-day factor
      const timeFactors = {
        // Peak hours have longer waits
        8: 1.2, 9: 1.3, 10: 1.4, 11: 1.3, // Morning peak
        12: 1.2, 13: 1.3, 14: 1.2, // Lunch peak
        17: 1.2, 18: 1.3, 19: 1.4, 20: 1.3, // Evening peak
      };

      const timeFactor = timeFactors[hour_of_day] || 1.0;
      baseWait *= timeFactor;

      // Day-of-week factor
      const dayFactors = {
        0: 0.8, // Sunday - slower
        1: 1.2, // Monday - busy
        2: 1.0, // Tuesday
        3: 1.0, // Wednesday
        4: 1.1, // Thursday
        5: 1.3, // Friday - busy
        6: 1.0, // Saturday
      };

      const dayFactor = dayFactors[day_of_week] || 1.0;
      baseWait *= dayFactor;

      // Queue length factor (longer queues = slower service)
      if (current_queue_length > 10) {
        baseWait *= 1.1;
      } else if (current_queue_length > 20) {
        baseWait *= 1.2;
      }

      const predictedWait = Math.round(baseWait);

      // Confidence tier based on data availability
      let confidenceTier = 'medium';
      if (current_queue_length < 3) {
        confidenceTier = 'high';
      } else if (current_queue_length > 15) {
        confidenceTier = 'low';
      }

      res.json({
        predicted_wait_mins: predictedWait,
        confidence_tier: confidenceTier,
        model: 'heuristic_fallback'
      });
    } catch (err) {
      console.error('Predict wait time error:', err);
      res.status(500).json({ error: 'Failed to predict wait time' });
    }
  }
);

/**
 * POST /predict/delay-check
 * Check if a counter is running behind schedule
 * Body: { queue_id, counter_id? }
 */
router.post('/delay-check',
  [
    body('queue_id').isUUID().withMessage('Valid queue_id required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { queue_id, counter_id } = req.body;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Try AI service first
      if (process.env.AI_SERVICE_ENABLED === 'true') {
        try {
          const aiResponse = await fetch(`${process.env.AI_SERVICE_URL}/predict/delay-check`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(req.body)
          });

          if (aiResponse.ok) {
            const aiData = await aiResponse.json();
            return res.json(aiData);
          }
        } catch (aiErr) {
          console.warn('AI service unavailable, using fallback');
        }
      }

      // Fallback: Check counter_delays table
      let query = supabaseAdmin
        .from('counter_delays')
        .select('*')
        .eq('queue_id', queue_id);

      if (counter_id) {
        query = query.eq('counter_id', counter_id);
      }

      const { data: delayRecords, error } = await query;

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      if (!delayRecords || delayRecords.length === 0) {
        return res.json({
          delayed: false,
          delay_multiplier: 1.0,
          message: 'No delay data available yet'
        });
      }

      // Calculate average delay factor
      let totalDelayFactor = 0;
      let count = 0;

      delayRecords.forEach(record => {
        if (record.recent_avg_delay_factor) {
          totalDelayFactor += record.recent_avg_delay_factor;
          count++;
        }
      });

      const avgDelayFactor = count > 0 ? totalDelayFactor / count : 1.0;
      const isDelayed = avgDelayFactor > 1.2; // More than 20% slower

      res.json({
        delayed: isDelayed,
        delay_multiplier: Math.round(avgDelayFactor * 100) / 100,
        counters_checked: delayRecords.length,
        message: isDelayed
          ? 'Service is running slower than usual'
          : 'Service is on schedule'
      });
    } catch (err) {
      console.error('Delay check error:', err);
      res.status(500).json({ error: 'Failed to check delay' });
    }
  }
);

module.exports = router;
