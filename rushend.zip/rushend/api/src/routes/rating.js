const express = require('express');
const router = express.Router();
const { getAuthUser } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

/**
 * POST /rating
 * Submit a rating for a served token
 * Body: { business_id, token_id, stars, comment? }
 */
router.post('/',
  getAuthUser,
  [
    body('business_id').isUUID().withMessage('Valid business_id required'),
    body('token_id').isUUID().withMessage('Valid token_id required'),
    body('stars').isInt({ min: 1, max: 5 }).withMessage('Stars must be 1-5')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { business_id, token_id, stars, comment } = req.body;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Verify token exists, belongs to user, and is served
      const { data: token, error: tokenError } = await supabaseAdmin
        .from('tokens')
        .select('*, queues!inner(business_id)')
        .eq('id', token_id)
        .eq('customer_id', req.user.id)
        .single();

      if (tokenError || !token) {
        return res.status(404).json({ error: 'Token not found or not authorized' });
      }

      if (token.status !== 'served') {
        return res.status(400).json({ error: 'Can only rate served tokens' });
      }

      if (token.queues.business_id !== business_id) {
        return res.status(400).json({ error: 'Token does not belong to this business' });
      }

      // Check if already rated
      const { data: existingRating } = await supabaseAdmin
        .from('ratings')
        .select('id')
        .eq('token_id', token_id)
        .single();

      if (existingRating) {
        return res.status(400).json({ error: 'Token already rated' });
      }

      // Create rating
      const { data: rating, error: ratingError } = await supabaseAdmin
        .from('ratings')
        .insert({
          business_id,
          token_id,
          customer_id: req.user.id,
          stars,
          comment: comment || null
        })
        .select()
        .single();

      if (ratingError) {
        return res.status(400).json({ error: ratingError.message });
      }

      // Business avg_rating is updated automatically via trigger

      res.status(201).json(rating);
    } catch (err) {
      console.error('Create rating error:', err);
      res.status(500).json({ error: 'Failed to create rating' });
    }
  }
);

/**
 * GET /rating/business/:id
 * Get ratings for a business
 */
router.get('/business/:id', async (req, res) => {
  const { id } = req.params;
  const { limit = 20, offset = 0 } = req.query;
  const supabase = req.app.locals.supabase;

  try {
    const { data: ratings, error, count } = await supabase
      .from('ratings')
      .select('*', { count: 'exact' })
      .eq('business_id', id)
      .order('created_at', { ascending: false })
      .range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1);

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({
      ratings,
      total: count,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
  } catch (err) {
    console.error('Get ratings error:', err);
    res.status(500).json({ error: 'Failed to get ratings' });
  }
});

/**
 * GET /rating/my
 * Get current user's ratings
 */
router.get('/my', getAuthUser, async (req, res) => {
  const supabaseAdmin = req.app.locals.supabaseAdmin;

  try {
    const { data: ratings, error } = await supabaseAdmin
      .from('ratings')
      .select('*, businesses(name, category)')
      .eq('customer_id', req.user.id)
      .order('created_at', { ascending: false });

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ ratings });
  } catch (err) {
    console.error('Get my ratings error:', err);
    res.status(500).json({ error: 'Failed to get ratings' });
  }
});

module.exports = router;
