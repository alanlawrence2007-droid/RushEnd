const express = require('express');
const router = express.Router();
const { getAuthUser, requireStaff } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

/**
 * POST /queue/:id/join
 * Join a queue - assigns next sequential token number, calls AI prediction
 * Body: { is_priority?: boolean }
 */
router.post('/:id/join',
  getAuthUser,
  async (req, res) => {
    const { id } = req.params;
    const { is_priority = false } = req.body;
    const supabase = req.app.locals.supabase;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Get queue details
      const { data: queue, error: queueError } = await supabase
        .from('queues')
        .select('*, businesses!inner(is_active), counters(is_open)')
        .eq('id', id)
        .single();

      if (queueError || !queue) {
        return res.status(404).json({ error: 'Queue not found' });
      }

      if (!queue.businesses.is_active) {
        return res.status(400).json({ error: 'Business is not active' });
      }

      // Get next token number
      const today = new Date().toISOString().split('T')[0];
      const { data: lastToken } = await supabaseAdmin
        .from('tokens')
        .select('token_number')
        .eq('queue_id', id)
        .gte('joined_at', today)
        .order('token_number', { ascending: false })
        .limit(1)
        .single();

      const nextNumber = (lastToken?.token_number || 0) + 1;

      // Calculate current position
      const { count: waitingCount } = await supabaseAdmin
        .from('tokens')
        .select('*', { count: 'exact', head: true })
        .eq('queue_id', id)
        .in('status', ['waiting', 'ready']);

      // Call AI prediction service
      const currentHour = new Date().getHours();
      const dayOfWeek = new Date().getDay();

      let predictedWait = queue.avg_service_time_mins * (waitingCount + 1);

      // Try to get ML prediction
      if (process.env.AI_SERVICE_ENABLED === 'true') {
        try {
          const aiResponse = await fetch(`${process.env.AI_SERVICE_URL}/predict/wait-time`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              queue_position: waitingCount + 1,
              hour_of_day: currentHour,
              day_of_week: dayOfWeek,
              current_queue_length: waitingCount,
              counter_avg_service_time: queue.avg_service_time_mins
            })
          });

          if (aiResponse.ok) {
            const aiData = await aiResponse.json();
            predictedWait = Math.round(aiData.predicted_wait_mins);
          }
        } catch (aiErr) {
          console.warn('AI service unavailable, using default calculation');
        }
      }

      // Create token
      const { data: token, error: tokenError } = await supabaseAdmin
        .from('tokens')
        .insert({
          queue_id: id,
          customer_id: req.user.id,
          token_number: nextNumber,
          status: 'waiting',
          is_priority,
          predicted_wait_mins: predictedWait,
          position_at_join: waitingCount + 1
        })
        .select()
        .single();

      if (tokenError) {
        return res.status(400).json({ error: tokenError.message });
      }

      // Broadcast to realtime channel
      await supabaseAdmin.channel(`queue:${id}`).send({
        type: 'broadcast',
        event: 'token_joined',
        payload: { token }
      });

      res.status(201).json({
        token,
        position: waitingCount + 1,
        predicted_wait_mins: predictedWait
      });
    } catch (err) {
      console.error('Join queue error:', err);
      res.status(500).json({ error: 'Failed to join queue' });
    }
  }
);

/**
 * GET /queue/:id/live
 * Get live queue status
 */
router.get('/:id/live', async (req, res) => {
  const { id } = req.params;
  const supabase = req.app.locals.supabase;
  const supabaseAdmin = req.app.locals.supabaseAdmin;

  try {
    // Get queue details
    const { data: queue, error: queueError } = await supabase
      .from('queues')
      .select('*, counters(is_open), businesses(name)')
      .eq('id', id)
      .single();

    if (queueError || !queue) {
      return res.status(404).json({ error: 'Queue not found' });
    }

    // Get waiting count
    const { count: waitingCount } = await supabaseAdmin
      .from('tokens')
      .select('*', { count: 'exact', head: true })
      .eq('queue_id', id)
      .in('status', ['waiting', 'ready']);

    // Get open counters
    const { data: counters } = await supabaseAdmin
      .from('counters')
      .select('id, name, is_open')
      .eq('business_id', queue.business_id)
      .eq('is_open', true);

    // Calculate average wait from recent tokens
    const { data: recentTokens } = await supabaseAdmin
      .from('tokens')
      .select('actual_wait_mins, served_at')
      .eq('queue_id', id)
      .eq('status', 'served')
      .not('actual_wait_mins', 'is', null)
      .order('served_at', { ascending: false })
      .limit(5);

    let avgWait = queue.avg_service_time_mins;
    if (recentTokens && recentTokens.length > 0) {
      const total = recentTokens.reduce((sum, t) => sum + (t.actual_wait_mins || 0), 0);
      avgWait = Math.round(total / recentTokens.length);
    }

    // Get currently being served
    const { data: currentTokens } = await supabaseAdmin
      .from('tokens')
      .select('id, token_number, called_at')
      .eq('queue_id', id)
      .eq('status', 'called')
      .order('called_at', { ascending: true });

    res.json({
      queue_id: id,
      queue_name: queue.service_name,
      business_name: queue.businesses?.name,
      waiting_count: waitingCount,
      open_counters: counters?.length || 0,
      counters: counters,
      avg_wait_mins: avgWait,
      currently_serving: currentTokens || []
    });
  } catch (err) {
    console.error('Get live queue error:', err);
    res.status(500).json({ error: 'Failed to get queue status' });
  }
});

/**
 * GET /queue/:id/tokens
 * Get all tokens in a queue (for staff)
 */
router.get('/:id/tokens',
  getAuthUser,
  requireStaff,
  async (req, res) => {
    const { id } = req.params;
    const { status } = req.query;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      let query = supabaseAdmin
        .from('tokens')
        .select('*, profiles(full_name, phone)')
        .eq('queue_id', id)
        .order('token_number', { ascending: true });

      if (status) {
        query = query.in('status', status.split(','));
      } else {
        query = query.in('status', ['waiting', 'ready', 'called']);
      }

      const { data: tokens, error } = await query;

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      res.json({ tokens });
    } catch (err) {
      console.error('Get queue tokens error:', err);
      res.status(500).json({ error: 'Failed to get tokens' });
    }
  }
);

module.exports = router;
