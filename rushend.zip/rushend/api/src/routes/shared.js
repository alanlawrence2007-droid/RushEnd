const express = require('express');
const router = express.Router();

/**
 * GET /shared/:share_code
 * Public endpoint - no auth required
 * Returns token status for a shared token
 */
router.get('/:share_code', async (req, res) => {
  const { share_code } = req.params;
  const supabaseAdmin = req.app.locals.supabaseAdmin;

  try {
    // Get share link
    const { data: shareLink, error: shareError } = await supabaseAdmin
      .from('shared_links')
      .select('*, tokens(*)')
      .eq('share_code', share_code)
      .single();

    if (shareError || !shareLink) {
      return res.status(404).json({ error: 'Share link not found' });
    }

    // Check if expired
    if (new Date(shareLink.expires_at) < new Date()) {
      return res.status(410).json({ error: 'Share link has expired' });
    }

    const token = shareLink.tokens;

    if (!token) {
      return res.status(404).json({ error: 'Token not found' });
    }

    // Get queue and business info
    const { data: queue } = await supabaseAdmin
      .from('queues')
      .select('service_name, avg_service_time_mins, businesses(name, address)')
      .eq('id', token.queue_id)
      .single();

    // Calculate position if waiting
    let position = null;
    if (['waiting', 'ready'].includes(token.status)) {
      const { data: aheadTokens } = await supabaseAdmin
        .from('tokens')
        .select('id, token_number, is_priority')
        .eq('queue_id', token.queue_id)
        .in('status', ['waiting', 'ready']);

      if (aheadTokens) {
        aheadTokens.sort((a, b) => {
          if (a.is_priority !== b.is_priority) {
            return b.is_priority ? 1 : -1;
          }
          return a.token_number - b.token_number;
        });
        position = aheadTokens.findIndex(t => t.id === token.id) + 1;
      }
    }

    // Only return safe, public information
    res.json({
      token: {
        id: token.id,
        token_number: token.token_number,
        status: token.status,
        is_priority: token.is_priority,
        predicted_wait_mins: token.predicted_wait_mins,
        joined_at: token.joined_at,
        called_at: token.called_at
      },
      position,
      queue: queue ? {
        service_name: queue.service_name,
        business_name: queue.businesses?.name,
        business_address: queue.businesses?.address
      } : null,
      share_expires_at: shareLink.expires_at
    });
  } catch (err) {
    console.error('Get shared token error:', err);
    res.status(500).json({ error: 'Failed to get token status' });
  }
});

module.exports = router;
