const express = require('express');
const router = express.Router();
const { getAuthUser, getUserProfile } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

/**
 * POST /auth/signup
 * Register a new user (customer or staff)
 * Body: { email, password, full_name, role, area?, phone?, language_pref? }
 */
router.post('/signup',
  [
    body('email').isEmail().withMessage('Valid email required'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('full_name').notEmpty().withMessage('Full name required'),
    body('role').isIn(['customer', 'staff']).withMessage('Role must be customer or staff')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password, full_name, role, area, phone, language_pref } = req.body;
    const supabase = req.app.locals.supabase;

    try {
      // Sign up user with Supabase Auth
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name,
            role,
            area: area || null,
            phone: phone || null,
            language_pref: language_pref || 'en'
          }
        }
      });

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      // Profile is auto-created via trigger
      res.status(201).json({
        message: 'User created successfully',
        user: data.user,
        session: data.session
      });
    } catch (err) {
      console.error('Signup error:', err);
      res.status(500).json({ error: 'Failed to create user' });
    }
  }
);

/**
 * POST /auth/login
 * Sign in existing user
 * Body: { email, password }
 */
router.post('/login',
  [
    body('email').isEmail().withMessage('Valid email required'),
    body('password').notEmpty().withMessage('Password required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password } = req.body;
    const supabase = req.app.locals.supabase;

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        return res.status(401).json({ error: error.message });
      }

      res.json({
        message: 'Login successful',
        user: data.user,
        session: data.session
      });
    } catch (err) {
      console.error('Login error:', err);
      res.status(500).json({ error: 'Failed to login' });
    }
  }
);

/**
 * POST /auth/logout
 * Sign out current user
 */
router.post('/logout', getAuthUser, async (req, res) => {
  const supabase = req.app.locals.supabase;

  try {
    const { error } = await supabase.auth.signOut();
    if (error) {
      return res.status(400).json({ error: error.message });
    }
    res.json({ message: 'Logged out successfully' });
  } catch (err) {
    console.error('Logout error:', err);
    res.status(500).json({ error: 'Failed to logout' });
  }
});

/**
 * GET /auth/me
 * Get current user's profile
 */
router.get('/me', getAuthUser, getUserProfile, async (req, res) => {
  const supabaseAdmin = req.app.locals.supabaseAdmin;

  try {
    const { data: profile, error } = await supabaseAdmin
      .from('profiles')
      .select('*')
      .eq('user_id', req.user.id)
      .single();

    if (error) {
      return res.status(404).json({ error: 'Profile not found' });
    }

    res.json({
      user: {
        id: req.user.id,
        email: req.user.email,
        ...profile
      }
    });
  } catch (err) {
    console.error('Get profile error:', err);
    res.status(500).json({ error: 'Failed to get profile' });
  }
});

/**
 * PATCH /auth/me
 * Update current user's profile
 */
router.patch('/me', getAuthUser, async (req, res) => {
  const { full_name, area, phone, language_pref } = req.body;
  const supabaseAdmin = req.app.locals.supabaseAdmin;

  try {
    const updates = {};
    if (full_name) updates.full_name = full_name;
    if (area !== undefined) updates.area = area;
    if (phone !== undefined) updates.phone = phone;
    if (language_pref) updates.language_pref = language_pref;
    updates.updated_at = new Date().toISOString();

    const { data, error } = await supabaseAdmin
      .from('profiles')
      .update(updates)
      .eq('user_id', req.user.id)
      .select()
      .single();

    if (error) {
      return res.status(400).json({ error: error.message });
    }

    res.json({ message: 'Profile updated', profile: data });
  } catch (err) {
    console.error('Update profile error:', err);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

module.exports = router;
