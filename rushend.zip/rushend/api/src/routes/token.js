const express = require('express');
const router = express.Router();
const { getAuthUser, requireStaff } = require('../middleware/auth');
const { body, validationResult } = require('express-validator');

/**
 * POST /token/manual
 * Staff-only: Create a manual walk-in token
 * Body: { queue_id, full_name?, phone?, is_priority? }
 */
router.post('/manual',
  getAuthUser,
  requireStaff,
  [
    body('queue_id').isUUID().withMessage('Valid queue_id required')
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { queue_id, full_name, phone, is_priority = false } = req.body;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Get queue and verify staff owns it
      const { data: queue, error: queueError } = await supabaseAdmin
        .from('queues')
        .select('*, businesses!inner(owner_id, is_active)')
        .eq('id', queue_id)
        .single();

      if (queueError || !queue) {
        return res.status(404).json({ error: 'Queue not found' });
      }

      if (queue.businesses.owner_id !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      // Get next token number
      const today = new Date().toISOString().split('T')[0];
      const { data: lastToken } = await supabaseAdmin
        .from('tokens')
        .select('token_number')
        .eq('queue_id', queue_id)
        .gte('joined_at', today)
        .order('token_number', { ascending: false })
        .limit(1)
        .single();

      const nextNumber = (lastToken?.token_number || 0) + 1;

      // Get current position
      const { count: waitingCount } = await supabaseAdmin
        .from('tokens')
        .select('*', { count: 'exact', head: true })
        .eq('queue_id', queue_id)
        .in('status', ['waiting', 'ready']);

      // Calculate predicted wait
      const currentHour = new Date().getHours();
      const dayOfWeek = new Date().getDay();
      let predictedWait = queue.avg_service_time_mins * (waitingCount + 1);

      if (process.env.AI_SERVICE_ENABLED === 'true') {
        try {
          const aiResponse = await fetch(`${process.env.AI_SERVICE_URL}/predict/wait-time`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              queue_position: waitingCount + 1,
              hour_of_day: currentHour,
              day_of_week: dayOfWeek,
              current_queue_length: waitingCount,
              counter_avg_service_time: queue.avg_service_time_mins
            })
          });

          if (aiResponse.ok) {
            const aiData = await aiResponse.json();
            predictedWait = Math.round(aiData.predicted_wait_mins);
          }
        } catch (aiErr) {
          console.warn('AI service unavailable');
        }
      }

      // Create manual token
      const { data: token, error: tokenError } = await supabaseAdmin
        .from('tokens')
        .insert({
          queue_id,
          customer_id: null, // No customer for manual entries
          token_number: nextNumber,
          status: 'waiting',
          is_priority,
          is_manual_entry: true,
          predicted_wait_mins: predictedWait,
          position_at_join: waitingCount + 1,
          notes: `Walk-in: ${full_name || 'Unknown'}${phone ? ` (${phone})` : ''}`
        })
        .select()
        .single();

      if (tokenError) {
        return res.status(400).json({ error: tokenError.message });
      }

      // Broadcast update
      await supabaseAdmin.channel(`queue:${queue_id}`).send({
        type: 'broadcast',
        event: 'token_joined',
        payload: { token }
      });

      res.status(201).json({
        token,
        position: waitingCount + 1,
        predicted_wait_mins: predictedWait
      });
    } catch (err) {
      console.error('Manual token error:', err);
      res.status(500).json({ error: 'Failed to create manual token' });
    }
  }
);

/**
 * GET /token/:id
 * Get token status with live position
 */
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  const supabaseAdmin = req.app.locals.supabaseAdmin;

  try {
    const { data: token, error } = await supabaseAdmin
      .from('tokens')
      .select('*, queues(service_name, avg_service_time_mins, business_id, businesses(name))')
      .eq('id', id)
      .single();

    if (error || !token) {
      return res.status(404).json({ error: 'Token not found' });
    }

    // Calculate current position if waiting
    let position = null;
    if (['waiting', 'ready'].includes(token.status)) {
      // Count tokens ahead (priority first, then by token number)
      const { data: aheadTokens } = await supabaseAdmin
        .from('tokens')
        .select('id, token_number, is_priority')
        .eq('queue_id', token.queue_id)
        .in('status', ['waiting', 'ready']);

      if (aheadTokens) {
        // Sort: priority first, then by token number
        aheadTokens.sort((a, b) => {
          if (a.is_priority !== b.is_priority) {
            return b.is_priority ? 1 : -1; // Priority comes first
          }
          return a.token_number - b.token_number;
        });

        position = aheadTokens.findIndex(t => t.id === token.id) + 1;
      }

      // Recalculate predicted wait based on current position
      const currentHour = new Date().getHours();
      const dayOfWeek = new Date().getDay();

      if (process.env.AI_SERVICE_ENABLED === 'true' && position) {
        try {
          const { count: currentQueueLength } = await supabaseAdmin
            .from('tokens')
            .select('*', { count: 'exact', head: true })
            .eq('queue_id', token.queue_id)
            .in('status', ['waiting', 'ready']);

          const aiResponse = await fetch(`${process.env.AI_SERVICE_URL}/predict/wait-time`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              queue_position: position,
              hour_of_day: currentHour,
              day_of_week: dayOfWeek,
              current_queue_length: currentQueueLength || 0,
              counter_avg_service_time: token.queues.avg_service_time_mins
            })
          });

          if (aiResponse.ok) {
            const aiData = await aiResponse.json();
            token.predicted_wait_mins = Math.round(aiData.predicted_wait_mins);
          }
        } catch (aiErr) {
          // Keep existing prediction
        }
      }
    }

    res.json({
      token,
      position,
      queue: token.queues
    });
  } catch (err) {
    console.error('Get token error:', err);
    res.status(500).json({ error: 'Failed to get token' });
  }
});

/**
 * PATCH /token/:id/priority
 * Staff-only: Toggle priority status
 */
router.patch('/:id/priority',
  getAuthUser,
  requireStaff,
  async (req, res) => {
    const { id } = req.params;
    const { is_priority } = req.body;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Verify ownership
      const { data: token, error: fetchError } = await supabaseAdmin
        .from('tokens')
        .select('*, queues!inner(business_id, businesses!inner(owner_id))')
        .eq('id', id)
        .single();

      if (fetchError || !token) {
        return res.status(404).json({ error: 'Token not found' });
      }

      if (token.queues.businesses.owner_id !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      const { data, error } = await supabaseAdmin
        .from('tokens')
        .update({ is_priority })
        .eq('id', id)
        .select()
        .single();

      if (error) {
        return res.status(400).json({ error: error.message });
      }

      // Broadcast update
      await supabaseAdmin.channel(`queue:${token.queue_id}`).send({
        type: 'broadcast',
        event: 'priority_changed',
        payload: { token: data }
      });

      res.json(data);
    } catch (err) {
      console.error('Update priority error:', err);
      res.status(500).json({ error: 'Failed to update priority' });
    }
  }
);

/**
 * POST /token/:id/call-next
 * Staff-only: Call the next token (respects priority)
 */
router.post('/:id/call-next',
  getAuthUser,
  requireStaff,
  async (req, res) => {
    const { id } = req.params; // This is actually queue_id for call-next
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Verify ownership
      const { data: queue, error: queueError } = await supabaseAdmin
        .from('queues')
        .select('*, businesses!inner(owner_id)')
        .eq('id', id)
        .single();

      if (queueError || !queue) {
        return res.status(404).json({ error: 'Queue not found' });
      }

      if (queue.businesses.owner_id !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      // Get next token to call (priority first)
      const { data: waitingTokens, error: tokenError } = await supabaseAdmin
        .from('tokens')
        .select('*')
        .eq('queue_id', id)
        .in('status', ['waiting', 'ready'])
        .order('is_priority', { ascending: false })
        .order('token_number', { ascending: true })
        .limit(1);

      if (tokenError || !waitingTokens || waitingTokens.length === 0) {
        return res.status(400).json({ error: 'No tokens waiting' });
      }

      const nextToken = waitingTokens[0];

      // Update token status
      const { data: updatedToken, error: updateError } = await supabaseAdmin
        .from('tokens')
        .update({
          status: 'called',
          called_at: new Date().toISOString()
        })
        .eq('id', nextToken.id)
        .select()
        .single();

      if (updateError) {
        return res.status(400).json({ error: updateError.message });
      }

      // Broadcast update
      await supabaseAdmin.channel(`queue:${id}`).send({
        type: 'broadcast',
        event: 'token_called',
        payload: { token: updatedToken }
      });

      await supabaseAdmin.channel(`business:${queue.business_id}`).send({
        type: 'broadcast',
        event: 'token_called',
        payload: { token: updatedToken }
      });

      res.json(updatedToken);
    } catch (err) {
      console.error('Call next error:', err);
      res.status(500).json({ error: 'Failed to call next token' });
    }
  }
);

/**
 * POST /token/:id/serve
 * Mark token as served, log to historical_service_logs
 */
router.post('/:id/serve',
  getAuthUser,
  requireStaff,
  async (req, res) => {
    const { id } = req.params;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Get token and verify ownership
      const { data: token, error: fetchError } = await supabaseAdmin
        .from('tokens')
        .select('*, queues!inner(business_id, avg_service_time_mins, businesses!inner(owner_id))')
        .eq('id', id)
        .single();

      if (fetchError || !token) {
        return res.status(404).json({ error: 'Token not found' });
      }

      if (token.queues.businesses.owner_id !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      const now = new Date();
      const joinedAt = new Date(token.joined_at);
      const actualWait = Math.round((now - joinedAt) / 60000); // in minutes

      // Update token
      const { data: updatedToken, error: updateError } = await supabaseAdmin
        .from('tokens')
        .update({
          status: 'served',
          served_at: now.toISOString(),
          actual_wait_mins: actualWait
        })
        .eq('id', id)
        .select()
        .single();

      if (updateError) {
        return res.status(400).json({ error: updateError.message });
      }

      // Log to historical_service_logs
      const dayOfWeek = joinedAt.getDay();
      const hourOfDay = joinedAt.getHours();

      await supabaseAdmin
        .from('historical_service_logs')
        .insert({
          queue_id: token.queue_id,
          counter_id: token.queues.counter_id,
          token_id: token.id,
          day_of_week: dayOfWeek,
          hour_of_day: hourOfDay,
          queue_length_at_join: token.position_at_join,
          position_at_join: token.position_at_join,
          predicted_wait_mins: token.predicted_wait_mins,
          actual_wait_mins: actualWait,
          service_duration_mins: token.called_at
            ? Math.round((now - new Date(token.called_at)) / 60000)
            : null,
          is_priority: token.is_priority
        });

      // Update counter delay tracking
      const counterId = token.queues.counter_id;
      if (counterId) {
        // Get or create delay record
        const { data: delayRecord } = await supabaseAdmin
          .from('counter_delays')
          .select('*')
          .eq('counter_id', counterId)
          .eq('queue_id', token.queue_id)
          .single();

        if (delayRecord) {
          // Update rolling averages
          let actualWaits = delayRecord.last_5_actual_waits || [];
          let predictedWaits = delayRecord.last_5_predicted_waits || [];

          actualWaits.push(actualWait);
          predictedWaits.push(token.predicted_wait_mins || actualWait);

          // Keep only last 5
          actualWaits = actualWaits.slice(-5);
          predictedWaits = predictedWaits.slice(-5);

          // Calculate delay factor
          const avgActual = actualWaits.reduce((a, b) => a + b, 0) / actualWaits.length;
          const avgPredicted = predictedWaits.reduce((a, b) => a + b, 0) / predictedWaits.length;
          const delayFactor = avgPredicted > 0 ? avgActual / avgPredicted : 1;

          await supabaseAdmin
            .from('counter_delays')
            .update({
              last_5_actual_waits: actualWaits,
              last_5_predicted_waits: predictedWaits,
              recent_avg_delay_factor: Math.round(delayFactor * 100) / 100,
              updated_at: now.toISOString()
            })
            .eq('id', delayRecord.id);
        } else {
          await supabaseAdmin
            .from('counter_delays')
            .insert({
              counter_id: counterId,
              queue_id: token.queue_id,
              last_5_actual_waits: [actualWait],
              last_5_predicted_waits: [token.predicted_wait_mins || actualWait],
              recent_avg_delay_factor: 1.0
            });
        }
      }

      // Broadcast update
      await supabaseAdmin.channel(`queue:${token.queue_id}`).send({
        type: 'broadcast',
        event: 'token_served',
        payload: { token: updatedToken, actual_wait_mins: actualWait }
      });

      res.json({
        token: updatedToken,
        actual_wait_mins: actualWait
      });
    } catch (err) {
      console.error('Serve token error:', err);
      res.status(500).json({ error: 'Failed to serve token' });
    }
  }
);

/**
 * POST /token/:id/skip
 * Skip a token
 */
router.post('/:id/skip',
  getAuthUser,
  requireStaff,
  async (req, res) => {
    const { id } = req.params;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Get token and verify ownership
      const { data: token, error: fetchError } = await supabaseAdmin
        .from('tokens')
        .select('*, queues!inner(businesses!inner(owner_id))')
        .eq('id', id)
        .single();

      if (fetchError || !token) {
        return res.status(404).json({ error: 'Token not found' });
      }

      if (token.queues.businesses.owner_id !== req.user.id) {
        return res.status(403).json({ error: 'Not authorized' });
      }

      const { data: updatedToken, error: updateError } = await supabaseAdmin
        .from('tokens')
        .update({ status: 'skipped' })
        .eq('id', id)
        .select()
        .single();

      if (updateError) {
        return res.status(400).json({ error: updateError.message });
      }

      // Broadcast update
      await supabaseAdmin.channel(`queue:${token.queue_id}`).send({
        type: 'broadcast',
        event: 'token_skipped',
        payload: { token: updatedToken }
      });

      res.json(updatedToken);
    } catch (err) {
      console.error('Skip token error:', err);
      res.status(500).json({ error: 'Failed to skip token' });
    }
  }
);

/**
 * POST /token/:id/leave
 * Customer leaves the queue
 */
router.post('/:id/leave',
  getAuthUser,
  async (req, res) => {
    const { id } = req.params;
    const supabaseAdmin = req.app.locals.supabaseAdmin;

    try {
      // Verify ownership
      const { data: token, error: fetchError } = await supabaseAdmin
        .from('tokens')
        .select('*')
        .eq('id', id)
        .eq('customer_id', req.user.id)
        .single();

      if (fetchError || !token) {
        return res.status(404).json({ error: 'Token not found or not authorized' });
      }

      if (!['waiting', 'ready'].includes(token.status)) {
        return res.status(400).json({ error: 'Cannot leave queue at this stage' });
      }

      const { data: updatedToken, error: updateError } = await supabaseAdmin
        .from('tokens')
        .update({ status: 'left' })
        .eq('id', id)
        .select()
        .single();

      if (updateError) {
        return res.status(400).json({ error: updateError.message });
      }

      // Broadcast update
      await supabaseAdmin.channel(`queue:${token.queue_id}`).send({
        type: 'broadcast',
        event: 'token_left',
        payload: { token: updatedToken }
      });

      res.json(updatedToken);
    } catch (err) {
      console.error('Leave queue error:', err);
      res.status(500).json({ error: 'Failed to leave queue' });
    }
  }
);

/**
 * POST /token/:id/share
 * Generate share link for token status
 */
router.post('/:id/share',
  getAuthUser,
  async (req, res) => {
    const { id } = req.params;
    const supabaseAdmin = req.app.locals.supabaseAdmin;
    const frontendUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

    try {
      // Verify ownership
      const { data: token, error: fetchError } = await supabaseAdmin
        .from('tokens')
        .select('*')
        .eq('id', id)
        .eq('customer_id', req.user.id)
        .single();

      if (fetchError || !token) {
        return res.status(404).json({ error: 'Token not found or not authorized' });
      }

      // Create or get existing share link
      const { data: existingLink } = await supabaseAdmin
        .from('shared_links')
        .select('*')
        .eq('token_id', id)
        .single();

      if (existingLink) {
        return res.json({
          share_url: `${frontendUrl}/shared/${existingLink.share_code}`,
          share_code: existingLink.share_code,
          expires_at: existingLink.expires_at
        });
      }

      // Create new share link
      const { data: shareLink, error: shareError } = await supabaseAdmin
        .from('shared_links')
        .insert({ token_id: id })
        .select()
        .single();

      if (shareError) {
        return res.status(400).json({ error: shareError.message });
      }

      res.json({
        share_url: `${frontendUrl}/shared/${shareLink.share_code}`,
        share_code: shareLink.share_code,
        expires_at: shareLink.expires_at
      });
    } catch (err) {
      console.error('Share token error:', err);
      res.status(500).json({ error: 'Failed to create share link' });
    }
  }
);

module.exports = router;
