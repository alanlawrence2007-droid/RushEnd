require('dotenv').config();

// Increase timeout for integration tests
jest.setTimeout(30000);

// Mock console.log in tests unless DEBUG is set
if (!process.env.DEBUG) {
  global.console = {
    ...console,
    log: jest.fn(),
    debug: jest.fn(),
    info: jest.fn(),
  };
}
