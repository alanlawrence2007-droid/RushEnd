-- RushEnd Complete Database Schema
-- Run this entire script in Supabase SQL Editor
-- https://supabase.com/dashboard/project/tqucvtjdpxnzvdxxzret/sql

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Custom types
CREATE TYPE user_role AS ENUM ('customer', 'staff');
CREATE TYPE token_status AS ENUM ('waiting', 'ready', 'called', 'served', 'skipped', 'left');

-- Profiles table (extends auth.users)
CREATE TABLE profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    area TEXT,
    phone TEXT,
    role user_role NOT NULL DEFAULT 'customer',
    language_pref TEXT DEFAULT 'en',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Businesses table
CREATE TABLE businesses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    address TEXT NOT NULL,
    area TEXT,
    lat DECIMAL(10, 8),
    lng DECIMAL(11, 8),
    qr_code_id TEXT UNIQUE NOT NULL DEFAULT encode(gen_random_bytes(8), 'hex'),
    avg_rating DECIMAL(3, 2) DEFAULT NULL,
    total_ratings INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Counters table (service windows)
CREATE TABLE counters (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id UUID REFERENCES businesses(id) ON DELETE CASCADE NOT NULL,
    name TEXT NOT NULL,
    identifier TEXT,
    is_open BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Queues table (service types)
CREATE TABLE queues (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id UUID REFERENCES businesses(id) ON DELETE CASCADE NOT NULL,
    counter_id UUID REFERENCES counters(id) ON DELETE SET NULL,
    service_name TEXT NOT NULL,
    service_code TEXT,
    avg_service_time_mins INTEGER DEFAULT 5,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tokens table (queue entries)
CREATE TABLE tokens (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    queue_id UUID REFERENCES queues(id) ON DELETE CASCADE NOT NULL,
    customer_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    token_number INTEGER NOT NULL,
    status token_status NOT NULL DEFAULT 'waiting',
    is_priority BOOLEAN DEFAULT FALSE,
    is_manual_entry BOOLEAN DEFAULT FALSE,
    predicted_wait_mins INTEGER,
    actual_wait_mins INTEGER,
    position_at_join INTEGER,
    joined_at TIMESTAMPTZ DEFAULT NOW(),
    called_at TIMESTAMPTZ,
    served_at TIMESTAMPTZ,
    notes TEXT
);

-- Historical service logs (for ML training)
CREATE TABLE historical_service_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    queue_id UUID REFERENCES queues(id) ON DELETE CASCADE NOT NULL,
    counter_id UUID REFERENCES counters(id) ON DELETE SET NULL,
    token_id UUID REFERENCES tokens(id) ON DELETE SET NULL,
    day_of_week INTEGER NOT NULL,
    hour_of_day INTEGER NOT NULL,
    queue_length_at_join INTEGER,
    position_at_join INTEGER,
    predicted_wait_mins INTEGER,
    actual_wait_mins INTEGER,
    service_duration_mins INTEGER,
    is_priority BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ratings table
CREATE TABLE ratings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    business_id UUID REFERENCES businesses(id) ON DELETE CASCADE NOT NULL,
    token_id UUID REFERENCES tokens(id) ON DELETE SET NULL UNIQUE,
    customer_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    stars INTEGER NOT NULL CHECK (stars >= 1 AND stars <= 5),
    comment TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Shared links table (for public token view)
CREATE TABLE shared_links (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    token_id UUID REFERENCES tokens(id) ON DELETE CASCADE NOT NULL UNIQUE,
    share_code TEXT UNIQUE NOT NULL DEFAULT encode(gen_random_bytes(6), 'hex'),
    expires_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '24 hours'),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Delay tracking per counter
CREATE TABLE counter_delays (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    counter_id UUID REFERENCES counters(id) ON DELETE CASCADE NOT NULL,
    queue_id UUID REFERENCES queues(id) ON DELETE CASCADE NOT NULL,
    recent_avg_delay_factor DECIMAL(4, 2) DEFAULT 1.0,
    last_5_actual_waits INTEGER[],
    last_5_predicted_waits INTEGER[],
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_profiles_user_id ON profiles(user_id);
CREATE INDEX idx_profiles_role ON profiles(role);
CREATE INDEX idx_businesses_owner_id ON businesses(owner_id);
CREATE INDEX idx_businesses_qr_code_id ON businesses(qr_code_id);
CREATE INDEX idx_businesses_area ON businesses(area);
CREATE INDEX idx_businesses_category ON businesses(category);
CREATE INDEX idx_counters_business_id ON counters(business_id);
CREATE INDEX idx_queues_business_id ON queues(business_id);
CREATE INDEX idx_queues_counter_id ON queues(counter_id);
CREATE INDEX idx_tokens_queue_id ON tokens(queue_id);
CREATE INDEX idx_tokens_customer_id ON tokens(customer_id);
CREATE INDEX idx_tokens_status ON tokens(status);
CREATE INDEX idx_tokens_joined_at ON tokens(joined_at);
CREATE INDEX idx_historical_logs_queue_id ON historical_service_logs(queue_id);
CREATE INDEX idx_historical_logs_day_hour ON historical_service_logs(day_of_week, hour_of_day);
CREATE INDEX idx_ratings_business_id ON ratings(business_id);
CREATE INDEX idx_shared_links_share_code ON shared_links(share_code);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_businesses_updated_at BEFORE UPDATE ON businesses
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_counters_updated_at BEFORE UPDATE ON counters
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_queues_updated_at BEFORE UPDATE ON queues
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to get current queue position for a token
CREATE OR REPLACE FUNCTION get_token_position(p_token_id UUID)
RETURNS INTEGER AS $$
DECLARE
    v_queue_id UUID;
    v_token_number INTEGER;
    v_is_priority BOOLEAN;
    v_position INTEGER;
BEGIN
    SELECT queue_id, token_number, is_priority
    INTO v_queue_id, v_token_number, v_is_priority
    FROM tokens WHERE id = p_token_id;

    IF v_queue_id IS NULL THEN
        RETURN NULL;
    END IF;

    IF v_is_priority THEN
        SELECT COUNT(*) INTO v_position
        FROM tokens
        WHERE queue_id = v_queue_id
          AND status IN ('waiting', 'ready')
          AND is_priority = TRUE
          AND token_number < v_token_number;
        v_position := v_position + 1;
    ELSE
        SELECT COUNT(*) INTO v_position
        FROM tokens
        WHERE queue_id = v_queue_id
          AND status IN ('waiting', 'ready')
          AND (
              is_priority = TRUE
              OR (is_priority = FALSE AND token_number < v_token_number)
          );
        v_position := v_position + 1;
    END IF;

    RETURN v_position;
END;
$$ LANGUAGE plpgsql;

-- Function to recalculate business average rating
CREATE OR REPLACE FUNCTION update_business_rating()
RETURNS TRIGGER AS $$
DECLARE
    v_business_id UUID;
    v_avg_rating DECIMAL(3,2);
    v_total INTEGER;
BEGIN
    IF TG_OP = 'INSERT' THEN
        v_business_id := NEW.business_id;
    ELSIF TG_OP = 'UPDATE' THEN
        v_business_id := NEW.business_id;
    ELSIF TG_OP = 'DELETE' THEN
        v_business_id := OLD.business_id;
    END IF;

    SELECT AVG(stars), COUNT(*)
    INTO v_avg_rating, v_total
    FROM ratings WHERE business_id = v_business_id;

    UPDATE businesses
    SET avg_rating = v_avg_rating,
        total_ratings = v_total,
        updated_at = NOW()
    WHERE id = v_business_id;

    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_business_rating
AFTER INSERT OR UPDATE OR DELETE ON ratings
FOR EACH ROW EXECUTE FUNCTION update_business_rating();

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE counters ENABLE ROW LEVEL SECURITY;
ALTER TABLE queues ENABLE ROW LEVEL SECURITY;
ALTER TABLE tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE historical_service_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE shared_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE counter_delays ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can read own profile" ON profiles FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own profile" ON profiles FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Staff can read customer profiles with tokens in their business" ON profiles FOR SELECT USING (
    EXISTS (SELECT 1 FROM businesses b WHERE b.owner_id = auth.uid())
    AND EXISTS (
        SELECT 1 FROM tokens t
        JOIN queues q ON t.queue_id = q.id
        JOIN businesses b ON q.business_id = b.id
        WHERE t.customer_id = profiles.user_id
        AND b.owner_id = auth.uid()
    )
);

-- RLS Policies for businesses
CREATE POLICY "Anyone can read active businesses" ON businesses FOR SELECT USING (is_active = TRUE);
CREATE POLICY "Owners can read own businesses" ON businesses FOR SELECT USING (auth.uid() = owner_id);
CREATE POLICY "Authenticated users can create businesses" ON businesses FOR INSERT WITH CHECK (auth.uid() = owner_id);
CREATE POLICY "Owners can update own businesses" ON businesses FOR UPDATE USING (auth.uid() = owner_id);

-- RLS Policies for counters
CREATE POLICY "Anyone can read counters of active businesses" ON counters FOR SELECT USING (
    EXISTS (SELECT 1 FROM businesses b WHERE b.id = counters.business_id AND b.is_active = TRUE)
);
CREATE POLICY "Staff can manage counters of own business" ON counters FOR ALL USING (
    EXISTS (SELECT 1 FROM businesses b WHERE b.id = counters.business_id AND b.owner_id = auth.uid())
);

-- RLS Policies for queues
CREATE POLICY "Anyone can read queues of active businesses" ON queues FOR SELECT USING (
    EXISTS (SELECT 1 FROM businesses b WHERE b.id = queues.business_id AND b.is_active = TRUE)
);
CREATE POLICY "Staff can manage queues of own business" ON queues FOR ALL USING (
    EXISTS (SELECT 1 FROM businesses b WHERE b.id = queues.business_id AND b.owner_id = auth.uid())
);

-- RLS Policies for tokens
CREATE POLICY "Customers can read own tokens" ON tokens FOR SELECT USING (auth.uid() = customer_id);
CREATE POLICY "Staff can read tokens in own business" ON tokens FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM queues q
        JOIN businesses b ON q.business_id = b.id
        WHERE q.id = tokens.queue_id
        AND b.owner_id = auth.uid()
    )
);
CREATE POLICY "Authenticated users can insert tokens" ON tokens FOR INSERT WITH CHECK (auth.uid() = customer_id OR auth.uid() IS NOT NULL);
CREATE POLICY "Staff can insert manual tokens" ON tokens FOR INSERT WITH CHECK (
    EXISTS (
        SELECT 1 FROM queues q
        JOIN businesses b ON q.business_id = b.id
        WHERE q.id = tokens.queue_id
        AND b.owner_id = auth.uid()
    )
);
CREATE POLICY "Customers can update own tokens" ON tokens FOR UPDATE USING (auth.uid() = customer_id) WITH CHECK (auth.uid() = customer_id);
CREATE POLICY "Staff can update tokens in own business" ON tokens FOR UPDATE USING (
    EXISTS (
        SELECT 1 FROM queues q
        JOIN businesses b ON q.business_id = b.id
        WHERE q.id = tokens.queue_id
        AND b.owner_id = auth.uid()
    )
);

-- RLS Policies for historical_service_logs
CREATE POLICY "Staff can read logs from own business" ON historical_service_logs FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM queues q
        JOIN businesses b ON q.business_id = b.id
        WHERE q.id = historical_service_logs.queue_id
        AND b.owner_id = auth.uid()
    )
);
CREATE POLICY "Service can insert logs" ON historical_service_logs FOR INSERT WITH CHECK (true);

-- RLS Policies for ratings
CREATE POLICY "Anyone can read ratings" ON ratings FOR SELECT USING (true);
CREATE POLICY "Customers can create ratings for own tokens" ON ratings FOR INSERT WITH CHECK (
    auth.uid() = customer_id
    AND EXISTS (
        SELECT 1 FROM tokens t
        WHERE t.id = ratings.token_id
        AND t.customer_id = auth.uid()
        AND t.status = 'served'
    )
);

-- RLS Policies for shared_links
CREATE POLICY "Public can read shared links by share_code" ON shared_links FOR SELECT USING (true);
CREATE POLICY "Customers can create share links for own tokens" ON shared_links FOR INSERT WITH CHECK (
    EXISTS (
        SELECT 1 FROM tokens t
        WHERE t.id = shared_links.token_id
        AND t.customer_id = auth.uid()
    )
);

-- RLS Policies for counter_delays
CREATE POLICY "Staff can read delays from own business" ON counter_delays FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM counters c
        JOIN businesses b ON c.business_id = b.id
        WHERE c.id = counter_delays.counter_id
        AND b.owner_id = auth.uid()
    )
);
CREATE POLICY "Service can manage delays" ON counter_delays FOR ALL USING (true);

-- Auth trigger: Create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (user_id, full_name, area, phone, role, language_pref)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
        NEW.raw_user_meta_data->>'area',
        NEW.raw_user_meta_data->>'phone',
        COALESCE((NEW.raw_user_meta_data->>'role')::public.user_role, 'customer'),
        COALESCE(NEW.raw_user_meta_data->>'language_pref', 'en')
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to check if user is staff
CREATE OR REPLACE FUNCTION is_staff()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM profiles WHERE user_id = auth.uid() AND role = 'staff'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get next token number for a queue
CREATE OR REPLACE FUNCTION get_next_token_number(p_queue_id UUID)
RETURNS INTEGER AS $$
DECLARE
    v_next_number INTEGER;
BEGIN
    SELECT COALESCE(MAX(token_number), 0) + 1
    INTO v_next_number
    FROM tokens
    WHERE queue_id = p_queue_id
      AND joined_at::date = CURRENT_DATE;
    RETURN v_next_number;
END;
$$ LANGUAGE plpgsql;

-- Function to get next token to call (respects priority)
CREATE OR REPLACE FUNCTION get_next_token_to_call(p_queue_id UUID)
RETURNS UUID AS $$
DECLARE
    v_token_id UUID;
BEGIN
    SELECT id INTO v_token_id
    FROM tokens
    WHERE queue_id = p_queue_id
      AND status IN ('waiting', 'ready')
      AND is_priority = TRUE
    ORDER BY token_number ASC
    LIMIT 1;

    IF v_token_id IS NULL THEN
        SELECT id INTO v_token_id
        FROM tokens
        WHERE queue_id = p_queue_id
          AND status IN ('waiting', 'ready')
          AND is_priority = FALSE
        ORDER BY token_number ASC
        LIMIT 1;
    END IF;
    RETURN v_token_id;
END;
$$ LANGUAGE plpgsql;

-- Realtime publication
DROP PUBLICATION IF EXISTS supabase_realtime;
CREATE PUBLICATION supabase_realtime FOR TABLE tokens, queues, counters, businesses;
ALTER PUBLICATION supabase_realtime ADD TABLE tokens;
ALTER PUBLICATION supabase_realtime ADD TABLE queues;
ALTER PUBLICATION supabase_realtime ADD TABLE counters;
ALTER PUBLICATION supabase_realtime ADD TABLE businesses;

-- Grant permissions
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated, service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated, service_role;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;