-- Auth trigger: Create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (user_id, full_name, area, phone, role, language_pref)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
        NEW.raw_user_meta_data->>'area',
        NEW.raw_user_meta_data->>'phone',
        COALESCE((NEW.raw_user_meta_data->>'role')::public.user_role, 'customer'),
        COALESCE(NEW.raw_user_meta_data->>'language_pref', 'en')
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger the function on user creation
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to check if user is staff (business owner)
CREATE OR REPLACE FUNCTION is_staff()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM profiles
        WHERE user_id = auth.uid()
        AND role = 'staff'
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get business_id for current staff user
CREATE OR REPLACE FUNCTION get_staff_business_id()
RETURNS UUID AS $$
DECLARE
    v_business_id UUID;
BEGIN
    SELECT id INTO v_business_id
    FROM businesses
    WHERE owner_id = auth.uid()
    LIMIT 1;

    RETURN v_business_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to generate next token number for a queue
CREATE OR REPLACE FUNCTION get_next_token_number(p_queue_id UUID)
RETURNS INTEGER AS $$
DECLARE
    v_next_number INTEGER;
BEGIN
    -- Get the highest token number for this queue today and increment
    SELECT COALESCE(MAX(token_number), 0) + 1
    INTO v_next_number
    FROM tokens
    WHERE queue_id = p_queue_id
      AND joined_at::date = CURRENT_DATE;

    RETURN v_next_number;
END;
$$ LANGUAGE plpgsql;

-- Function to get next token to call (respects priority)
CREATE OR REPLACE FUNCTION get_next_token_to_call(p_queue_id UUID)
RETURNS UUID AS $$
DECLARE
    v_token_id UUID;
BEGIN
    -- First, check for priority tokens
    SELECT id INTO v_token_id
    FROM tokens
    WHERE queue_id = p_queue_id
      AND status IN ('waiting', 'ready')
      AND is_priority = TRUE
    ORDER BY token_number ASC
    LIMIT 1;

    -- If no priority tokens, get the next regular token
    IF v_token_id IS NULL THEN
        SELECT id INTO v_token_id
        FROM tokens
        WHERE queue_id = p_queue_id
          AND status IN ('waiting', 'ready')
          AND is_priority = FALSE
        ORDER BY token_number ASC
        LIMIT 1;
    END IF;

    RETURN v_token_id;
END;
$$ LANGUAGE plpgsql;

-- Realtime publication for live updates
-- Note: This needs to be configured in Supabase dashboard or via SQL
DROP PUBLICATION IF EXISTS supabase_realtime;
CREATE PUBLICATION supabase_realtime FOR TABLE tokens, queues, counters, businesses;

-- Add tables to realtime publication
ALTER PUBLICATION supabase_realtime ADD TABLE tokens;
ALTER PUBLICATION supabase_realtime ADD TABLE queues;
ALTER PUBLICATION supabase_realtime ADD TABLE counters;
ALTER PUBLICATION supabase_realtime ADD TABLE businesses;
