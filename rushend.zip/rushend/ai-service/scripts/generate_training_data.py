"""
Generate synthetic training data for the wait time prediction model.
Creates realistic patterns for different business categories:
- Hospitals: slower Monday mornings
- Restaurants: peaks at lunch (1-2pm) and dinner (8-9pm)
- Banks: slower near month-end
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import os

np.random.seed(42)
random.seed(42)

def generate_training_data(n_samples=1000):
    """Generate synthetic historical service logs"""

    data = []

    # Business category patterns
    categories = {
        'hospital': {
            'avg_service_time': 15,
            'hour_factors': {
                8: 1.4, 9: 1.5, 10: 1.3, 11: 1.2,  # Morning busy
                12: 0.9, 13: 0.9, 14: 1.0, 15: 1.0,  # Afternoon
                16: 1.1, 17: 1.0, 18: 0.8, 19: 0.7,  # Evening slower
            },
            'day_factors': {0: 0.7, 1: 1.4, 2: 1.1, 3: 1.0, 4: 1.0, 5: 1.1, 6: 0.8}  # Monday busy
        },
        'restaurant': {
            'avg_service_time': 8,
            'hour_factors': {
                11: 1.1, 12: 1.5, 13: 1.4, 14: 1.0,  # Lunch peak
                18: 1.2, 19: 1.6, 20: 1.5, 21: 1.2,  # Dinner peak
            },
            'day_factors': {0: 0.6, 1: 0.8, 2: 0.9, 3: 1.0, 4: 1.1, 5: 1.3, 6: 1.4}  # Weekend busy
        },
        'bank': {
            'avg_service_time': 12,
            'hour_factors': {
                9: 1.3, 10: 1.2, 11: 1.1, 14: 1.2, 15: 1.3, 16: 1.1,  # Business hours
            },
            'day_factors': {0: 0.5, 1: 1.2, 2: 1.0, 3: 1.0, 4: 1.1, 5: 1.2, 6: 0.3}  # Closed weekends
        },
        'government': {
            'avg_service_time': 20,
            'hour_factors': {
                9: 1.4, 10: 1.3, 11: 1.2, 14: 1.2, 15: 1.1,  # Office hours
            },
            'day_factors': {0: 0.4, 1: 1.3, 2: 1.1, 3: 1.1, 4: 1.0, 5: 1.1, 6: 0.3}
        },
        'other': {
            'avg_service_time': 10,
            'hour_factors': {},
            'day_factors': {}
        }
    }

    # Generate samples
    for _ in range(n_samples):
        # Random category with realistic distribution
        category = random.choices(
            ['hospital', 'restaurant', 'bank', 'government', 'other'],
            weights=[0.25, 0.30, 0.20, 0.15, 0.10]
        )[0]

        cat_config = categories[category]

        # Random day and hour
        day_of_week = random.randint(0, 6)
        hour_of_day = random.randint(8, 20)

        # Queue parameters
        queue_length = max(0, int(np.random.exponential(8)))  # Average 8 people waiting
        position = random.randint(1, max(1, queue_length) + 1)
        is_priority = random.random() < 0.15  # 15% priority tokens

        # Calculate base wait time
        avg_service_time = cat_config['avg_service_time']
        base_wait = position * avg_service_time

        # Apply time factors
        hour_factor = cat_config['hour_factors'].get(hour_of_day, 1.0)
        base_wait *= hour_factor

        # Apply day factors
        day_factor = cat_config['day_factors'].get(day_of_week, 1.0)
        base_wait *= day_factor

        # Queue length factor (longer queues slow things down)
        if queue_length > 10:
            base_wait *= 1.1
        if queue_length > 20:
            base_wait *= 1.15

        # Priority tokens get faster service (but still wait for their turn)
        if is_priority:
            base_wait *= 0.85

        # Add noise
        noise = np.random.normal(0, base_wait * 0.15)
        actual_wait = max(1, int(base_wait + noise))

        data.append({
            'queue_position': position,
            'hour_of_day': hour_of_day,
            'day_of_week': day_of_week,
            'current_queue_length': queue_length,
            'counter_avg_service_time': avg_service_time,
            'is_priority': int(is_priority),
            'category': category,
            'actual_wait_mins': actual_wait
        })

    return pd.DataFrame(data)

def train_model(df):
    """Train a gradient boosting regressor"""
    from sklearn.ensemble import GradientBoostingRegressor
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_absolute_error, r2_score
    import joblib

    # Features
    feature_cols = ['queue_position', 'hour_of_day', 'day_of_week',
                    'current_queue_length', 'counter_avg_service_time']
    X = df[feature_cols]
    y = df['actual_wait_mins']

    # Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train model
    model = GradientBoostingRegressor(
        n_estimators=100,
        max_depth=5,
        learning_rate=0.1,
        random_state=42
    )
    model.fit(X_train, y_train)

    # Evaluate
    y_pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)

    print(f"Model Performance:")
    print(f"  MAE: {mae:.2f} minutes")
    print(f"  R²: {r2:.3f}")

    # Save model
    models_dir = os.path.join(os.path.dirname(__file__), "..", "models")
    os.makedirs(models_dir, exist_ok=True)
    model_path = os.path.join(models_dir, "wait_time_model.joblib")
    joblib.dump(model, model_path)
    print(f"\nModel saved to {model_path}")

    return model, mae, r2

def generate_sql_seed(df):
    """Generate SQL INSERT statements for Supabase"""
    import uuid

    sql_statements = []

    for _, row in df.iterrows():
        log_id = str(uuid.uuid4())
        queue_id = str(uuid.uuid4())  # Would be real queue_id in production

        sql = f"""INSERT INTO historical_service_logs (id, queue_id, day_of_week, hour_of_day, queue_length_at_join, position_at_join, predicted_wait_mins, actual_wait_mins, is_priority)
VALUES ('{log_id}', '{queue_id}', {row['day_of_week']}, {row['hour_of_day']}, {row['current_queue_length']}, {row['queue_position']}, {row['actual_wait_mins']}, {row['actual_wait_mins']}, {row['is_priority']});"""
        sql_statements.append(sql)

    return "\n".join(sql_statements)

if __name__ == "__main__":
    print("Generating synthetic training data...")
    df = generate_training_data(1000)

    print(f"\nGenerated {len(df)} samples")
    print(f"\nSample statistics:")
    print(df.describe())

    print("\nTraining model...")
    model, mae, r2 = train_model(df)

    # Test predictions
    print("\nTest predictions:")
    test_cases = [
        {"queue_position": 1, "hour_of_day": 10, "day_of_week": 1, "current_queue_length": 5, "counter_avg_service_time": 10},
        {"queue_position": 5, "hour_of_day": 13, "day_of_week": 5, "current_queue_length": 12, "counter_avg_service_time": 8},
        {"queue_position": 10, "hour_of_day": 9, "day_of_week": 1, "current_queue_length": 20, "counter_avg_service_time": 15},
    ]

    for case in test_cases:
        pred = model.predict([[
            case['queue_position'],
            case['hour_of_day'],
            case['day_of_week'],
            case['current_queue_length'],
            case['counter_avg_service_time']
        ]])[0]
        print(f"  Position {case['queue_position']}, Hour {case['hour_of_day']}, Day {case['day_of_week']}: {pred:.1f} mins")

    print("\nDone!")
