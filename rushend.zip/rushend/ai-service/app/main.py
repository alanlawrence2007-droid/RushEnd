"""
RushEnd AI Service - Wait Time Prediction
Phase 6: ML model for predicting queue wait times
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional
import joblib
import numpy as np
import os
from datetime import datetime

app = FastAPI(
    title="RushEnd AI Service",
    description="ML-powered wait time prediction for queue management",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Model path
MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "wait_time_model.joblib")
model = None

class WaitTimeRequest(BaseModel):
    queue_position: int = Field(..., ge=1, description="Position in queue")
    hour_of_day: int = Field(..., ge=0, le=23, description="Hour of day (0-23)")
    day_of_week: int = Field(..., ge=0, le=6, description="Day of week (0=Sunday, 6=Saturday)")
    current_queue_length: int = Field(..., ge=0, description="Current number waiting")
    counter_avg_service_time: int = Field(..., ge=1, description="Average service time in minutes")

class WaitTimeResponse(BaseModel):
    predicted_wait_mins: int
    confidence_tier: str
    model: str

class DelayCheckRequest(BaseModel):
    queue_id: str
    counter_id: Optional[str] = None

class DelayCheckResponse(BaseModel):
    delayed: bool
    delay_multiplier: float
    counters_checked: int
    message: str

def load_model():
    """Load the trained model"""
    global model
    if os.path.exists(MODEL_PATH):
        model = joblib.load(MODEL_PATH)
        print(f"Model loaded from {MODEL_PATH}")
    else:
        print(f"No model found at {MODEL_PATH}, using heuristic fallback")
        model = None

@app.on_event("startup")
async def startup_event():
    load_model()

@app.get("/health")
async def health():
    return {"status": "ok", "timestamp": datetime.utcnow().isoformat()}

@app.post("/predict/wait-time", response_model=WaitTimeResponse)
async def predict_wait_time(request: WaitTimeRequest):
    """
    Predict wait time based on queue position, time, and service characteristics.

    Uses a trained gradient boosting regressor if available, otherwise falls back
    to a heuristic calculation.
    """
    try:
        if model is not None:
            # Use ML model
            features = np.array([[
                request.queue_position,
                request.hour_of_day,
                request.day_of_week,
                request.current_queue_length,
                request.counter_avg_service_time
            ]])

            predicted_wait = model.predict(features)[0]
            predicted_wait = max(1, round(predicted_wait))

            # Confidence based on training data coverage
            confidence = "high"
            if request.current_queue_length > 20:
                confidence = "low"
            elif request.current_queue_length > 10:
                confidence = "medium"

            return WaitTimeResponse(
                predicted_wait_mins=predicted_wait,
                confidence_tier=confidence,
                model="gradient_boosting"
            )
        else:
            # Heuristic fallback
            base_wait = request.queue_position * request.counter_avg_service_time

            # Time-of-day factors
            time_factors = {
                8: 1.2, 9: 1.3, 10: 1.4, 11: 1.3,
                12: 1.2, 13: 1.3, 14: 1.2,
                17: 1.2, 18: 1.3, 19: 1.4, 20: 1.3,
            }
            base_wait *= time_factors.get(request.hour_of_day, 1.0)

            # Day-of-week factors
            day_factors = {0: 0.8, 1: 1.2, 2: 1.0, 3: 1.0, 4: 1.1, 5: 1.3, 6: 1.0}
            base_wait *= day_factors.get(request.day_of_week, 1.0)

            # Queue length factor
            if request.current_queue_length > 10:
                base_wait *= 1.1
            if request.current_queue_length > 20:
                base_wait *= 1.2

            predicted_wait = max(1, round(base_wait))

            confidence = "medium"
            if request.current_queue_length < 3:
                confidence = "high"
            elif request.current_queue_length > 15:
                confidence = "low"

            return WaitTimeResponse(
                predicted_wait_mins=predicted_wait,
                confidence_tier=confidence,
                model="heuristic_fallback"
            )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")

@app.post("/predict/delay-check", response_model=DelayCheckResponse)
async def check_delay(request: DelayCheckRequest):
    """
    Check if a counter is running behind schedule.
    Compares actual vs predicted wait times from the last 5 served tokens.
    Returns delay_multiplier if actual > 120% of predicted.
    """
    # This would typically query the database
    # For now, return a placeholder response
    return DelayCheckResponse(
        delayed=False,
        delay_multiplier=1.0,
        counters_checked=1,
        message="Service is on schedule"
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
